package com.multitool.casino.games;

import com.multitool.casino.config.ConfigManager;
import com.multitool.casino.config.Messages;
import com.multitool.casino.listeners.gui.CasinoGuis;
import com.multitool.casino.listeners.gui.GuiHolder;
import com.multitool.casino.plugin.CasinoPlugin;
import com.multitool.casino.storage.StatsService;
import com.multitool.casino.utils.CooldownManager;
import com.multitool.casino.utils.ItemRewards;
import java.util.Map;
import java.util.UUID;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ThreadLocalRandom;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitRunnable;

public final class ResourceRouletteGame {
   private final CasinoPlugin plugin;
   private final ConfigManager config;
   private final Messages messages;
   private final StatsService stats;
   private final CooldownManager cooldowns;
   private final Map<UUID, ResourceRouletteGame.RollTask> pending = new ConcurrentHashMap<>();

   public ResourceRouletteGame(CasinoPlugin plugin, ConfigManager config, Messages messages, StatsService stats, CooldownManager cooldowns) {
      this.plugin = plugin;
      this.config = config;
      this.messages = messages;
      this.stats = stats;
      this.cooldowns = cooldowns;
   }

   public boolean busy(UUID uuid) {
      return this.pending.containsKey(uuid);
   }

   public void play(Player player, GuiHolder holder) {
      ConfigManager.ResourceSettings settings = this.config.resource();
      ItemStack stake = holder.getInventory().getItem(holder.inputSlot());
      String forbidden = stake == null ? null : settings.forbiddenName(stake);
      if (stake == null || stake.getType().isAir()) {
         this.messages.sendPrefixed(player, "games.resource.empty");
      } else if (forbidden != null) {
         this.messages.sendPrefixed(player, "games.resource.item-forbidden", Messages.p("item", forbidden));
      } else {
         UUID uuid = player.getUniqueId();
         if (this.pending.containsKey(uuid)) {
            this.messages.sendPrefixed(player, "games.busy");
         } else {
            long remaining = this.cooldowns.remainingSeconds(uuid);
            if (remaining > 0L) {
               this.messages.sendPrefixed(player, "errors.cooldown", Messages.p("time", remaining));
            } else {
               this.plugin.resourceCooldown().gateAndMark(player, () -> this.start(player, holder, settings));
            }
         }
      }
   }

   private void start(Player player, GuiHolder holder, ConfigManager.ResourceSettings settings) {
      if (!player.isOnline() || player.getOpenInventory().getTopInventory().getHolder() != holder) {
         return;
      }

      ItemStack stake = holder.getInventory().getItem(holder.inputSlot());
      String forbidden = stake == null ? null : settings.forbiddenName(stake);
      if (stake == null || stake.getType().isAir()) {
         this.messages.sendPrefixed(player, "games.resource.empty");
         return;
      }

      if (forbidden != null) {
         this.messages.sendPrefixed(player, "games.resource.item-forbidden", Messages.p("item", forbidden));
         return;
      }

      UUID uuid = player.getUniqueId();
      if (this.pending.containsKey(uuid)) {
         this.messages.sendPrefixed(player, "games.busy");
         return;
      }

      long remaining = this.cooldowns.remainingSeconds(uuid);
      if (remaining > 0L) {
         this.messages.sendPrefixed(player, "errors.cooldown", Messages.p("time", remaining));
         return;
      }

      ItemStack bet = stake.clone();
      holder.getInventory().setItem(holder.inputSlot(), null);
      this.cooldowns.mark(uuid);
      holder.locked(true);
      ConfigManager.ResourceMultiplier reward = ThreadLocalRandom.current().nextInt(100) < settings.winChance()
         ? settings.randomMultiplier(ThreadLocalRandom.current())
         : null;
      ResourceRouletteGame.RollTask task = new ResourceRouletteGame.RollTask(player, holder, settings, bet, reward);
      this.pending.put(uuid, task);
      task.runTaskTimer(this.plugin, 1L, (long)settings.tickPeriod());
   }

   public void refund(Player player) {
      ResourceRouletteGame.RollTask task = this.pending.remove(player.getUniqueId());
      if (task != null) {
         task.cancel();
         ItemRewards.give(player, task.bet);
      }
   }

   public void shutdown() {
      for (Entry<UUID, ResourceRouletteGame.RollTask> entry : Map.copyOf(this.pending).entrySet()) {
         if (this.pending.remove(entry.getKey(), entry.getValue())) {
            ResourceRouletteGame.RollTask task = entry.getValue();
            task.cancel();
            Player player = Bukkit.getPlayer(entry.getKey());
            if (player != null) {
               ItemRewards.give(player, task.bet);
            }
         }
      }

      this.pending.clear();
   }

   private final class RollTask extends BukkitRunnable {
      private final Player player;
      private final GuiHolder holder;
      private final ConfigManager.ResourceSettings settings;
      private final ItemStack bet;
      private final ConfigManager.ResourceMultiplier reward;
      private int tick;

      private RollTask(Player player, GuiHolder holder, ConfigManager.ResourceSettings settings, ItemStack bet, ConfigManager.ResourceMultiplier reward) {
         this.player = player;
         this.holder = holder;
         this.settings = settings;
         this.bet = bet;
         this.reward = reward;
      }

      public void run() {
         if (this.tick >= this.settings.animationTicks()) {
            this.cancel();
            this.finish();
         } else {
            this.player.sendActionBar(ResourceRouletteGame.this.messages.component("games.resource.spin"));
            this.tick++;
         }
      }

      private void finish() {
         if (ResourceRouletteGame.this.pending.remove(this.player.getUniqueId(), this)) {
            this.holder.locked(false);
            long stake = (long)this.bet.getAmount();
            long payout = this.reward == null ? 0L : Math.round((double)stake * this.reward.multiplier());
            ResourceRouletteGame.this.stats.record(this.player.getUniqueId(), this.player.getName(), stake, payout);
            if (this.player.isOnline()) {
               if (this.reward != null) {
                  ItemRewards.giveCopies(this.player, this.bet, payout);
                  ResourceRouletteGame.this.messages
                     .sendPrefixed(
                        this.player,
                        "games.resource.win",
                        Messages.p("payout", payout),
                        Messages.p("stake", stake),
                        Messages.p("multiplier", CasinoGuis.multiplier(this.reward.multiplier()))
                     );
               } else {
                  ResourceRouletteGame.this.messages.sendPrefixed(this.player, "games.resource.lose", Messages.p("stake", stake));
               }

               boolean win = this.reward != null;
               CasinoGuis.setResultButton(
                  this.holder,
                  win ? Material.EMERALD_BLOCK : Material.RED_CONCRETE,
                  ResourceRouletteGame.this.messages.component(win ? "gui.result.win" : "gui.result.lose", Messages.p("amount", payout))
               );
            }
         }
      }
   }
}
