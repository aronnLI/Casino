package com.multitool.casino.listeners;

import com.multitool.casino.config.ConfigManager;
import com.multitool.casino.config.Messages;
import com.multitool.casino.games.GameType;
import com.multitool.casino.listeners.gui.CasinoGuis;
import com.multitool.casino.listeners.gui.GuiHolder;
import com.multitool.casino.plugin.CasinoPlugin;
import com.multitool.casino.utils.ItemRewards;
import java.util.logging.Level;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

public final class GuiListener implements Listener {
   private final CasinoPlugin plugin;

   public GuiListener(CasinoPlugin plugin) {
      this.plugin = plugin;
   }

   @EventHandler
   public void onClick(InventoryClickEvent event) {
      if (event.getWhoClicked() instanceof Player player) {
         Inventory top = event.getView().getTopInventory();
         if (top.getHolder() instanceof GuiHolder holder) {
            int raw = event.getRawSlot();
            boolean topClick = raw >= 0 && raw < top.getSize();
            if (holder.locked()) {
               event.setCancelled(true);
            } else if (!topClick) {
               if (event.isShiftClick()) {
                  event.setCancelled(true);
               }
            } else if (holder.isInput(raw)) {
               this.handleInput(event, holder, player);
            } else {
               event.setCancelled(true);

               try {
                  switch (holder.type()) {
                     case MAIN:
                        this.onMain(player, raw);
                        break;
                     case DIAMOND:
                        this.onDiamond(player, holder, raw, event.getClick());
                        break;
                     case RESOURCE:
                        this.onResource(player, holder, raw);
                        break;
                     case TREASURE_MENU:
                        this.onTreasureMenu(player, holder, raw, event.getClick());
                        break;
                     case TREASURE_FIELD:
                        this.plugin.treasureGame().click(player, holder, raw, event.getClick());
                  }
               } catch (Throwable var8) {
                  this.plugin.getLogger().log(Level.SEVERE, "Ошибка обработки клика в меню казино (" + holder.type() + ", слот " + raw + ")", var8);
                  player.closeInventory();
                  this.plugin.messages().sendPrefixed(player, "general.command-error");
               }
            }
         }
      }
   }

   @EventHandler
   public void onDrag(InventoryDragEvent event) {
      Inventory top = event.getView().getTopInventory();
      if (top.getHolder() instanceof GuiHolder holder) {
         if (!holder.locked() && event.getWhoClicked() instanceof Player player) {
            int input = holder.inputSlot();
            if (input < 0 && holder.inputSlots().length == 0) {
               event.setCancelled(true);
            } else {
               for (int raw : event.getRawSlots()) {
                  if (raw < top.getSize() && !holder.isInput(raw)) {
                     event.setCancelled(true);
                     return;
                  }
               }

               ItemStack cursor = event.getOldCursor();
               if (cursor != null && !cursor.getType().isAir()) {
                  if (!this.allowedInput(holder, player, cursor)) {
                     event.setCancelled(true);
                  }
               } else {
                  event.setCancelled(true);
               }
            }
         } else {
            event.setCancelled(true);
         }
      }
   }

   @EventHandler
   public void onClose(InventoryCloseEvent event) {
      if (event.getPlayer() instanceof Player player) {
         if (event.getInventory().getHolder() instanceof GuiHolder holder) {
            if (holder.type() == GuiHolder.Type.TREASURE_FIELD) {
               this.plugin.treasureGame().closed(player, holder);
            } else {
               Inventory top = holder.getInventory();

               for (int slot = 0; slot < top.getSize(); slot++) {
                  if (holder.isInput(slot)) {
                     ItemStack left = top.getItem(slot);
                     if (left != null && !left.getType().isAir()) {
                        top.setItem(slot, null);
                        ItemRewards.give(player, left);
                     }
                  }
               }
            }
         }
      }
   }

   private void handleInput(InventoryClickEvent event, GuiHolder holder, Player player) {
      ClickType click = event.getClick();
      if (!event.isShiftClick()
         && click != ClickType.NUMBER_KEY
         && click != ClickType.DOUBLE_CLICK
         && click != ClickType.SWAP_OFFHAND
         && click != ClickType.CONTROL_DROP) {
         ItemStack cursor = event.getCursor();
         if (cursor != null && !cursor.getType().isAir()) {
            if (!this.allowedInput(holder, player, cursor)) {
               event.setCancelled(true);
            }
         }
      } else {
         event.setCancelled(true);
      }
   }

   private boolean allowedInput(GuiHolder holder, Player player, ItemStack stack) {
      Messages messages = this.plugin.messages();
      String forbidden = this.plugin.configManager().resource().forbiddenName(stack);
      if (forbidden == null) {
         return true;
      } else {
         messages.sendPrefixed(player, "games.resource.item-forbidden", Messages.p("item", forbidden));
         return false;
      }
   }

   private void onMain(Player player, int slot) {
      Messages messages = this.plugin.messages();
      ConfigManager config = this.plugin.configManager();
      switch (slot) {
         case 21:
            if (!player.hasPermission(GameType.DIAMOND.permission())) {
               messages.sendPrefixed(player, "general.no-permission");
               return;
            }

            if (this.plugin.points() == null) {
               messages.sendPrefixed(player, "general.economy-missing");
               return;
            }

            CasinoGuis.openDiamond(player, messages, config, this.plugin.points().balance(player.getUniqueId()));
            break;
         case 22:
            if (!player.hasPermission(GameType.RESOURCE.permission())) {
               messages.sendPrefixed(player, "general.no-permission");
               return;
            }

            this.plugin.resourceCooldown().gate(player, () -> CasinoGuis.openResource(player, messages, config));
            break;
         case 23:
            if (!player.hasPermission(GameType.TREASURE.permission())) {
               messages.sendPrefixed(player, "general.no-permission");
               return;
            }

            this.plugin.treasureGame().openMenu(player);
      }
   }

   private void onDiamond(Player player, GuiHolder holder, int slot, ClickType click) {
      ConfigManager config = this.plugin.configManager();
      ConfigManager.DiamondSettings settings = config.diamond();
      long current = holder.amount();
      switch (slot) {
         case 39:
            long step = current >= 1000L ? 100L : 10L;
            if (click.isShiftClick() && click.isLeftClick()) {
               holder.amount(settings.maxBet());
            } else if (click.isShiftClick() && click.isRightClick()) {
               holder.amount(settings.minBet());
            } else if (click.isLeftClick()) {
               holder.amount(settings.clamp(current + step));
            } else {
               if (!click.isRightClick()) {
                  return;
               }

               holder.amount(settings.clamp(current - step));
            }

            long balance = this.plugin.points() == null ? 0L : this.plugin.points().balance(player.getUniqueId());
            CasinoGuis.renderDiamondBet(holder, this.plugin.messages(), settings, balance);
            break;
         case 40:
            this.plugin.diamondGame().play(player, holder);
      }
   }

   private void onTreasureMenu(Player player, GuiHolder holder, int slot, ClickType click) {
      ConfigManager.TreasureSettings settings = this.plugin.configManager().treasure();
      switch (slot) {
         case 13:
            long current = holder.amount();
            long next;
            if (click == ClickType.DROP || click == ClickType.CONTROL_DROP) {
               next = settings.maxBet();
            } else if (click.isShiftClick() && click.isLeftClick()) {
               next = current + settings.bigStep();
            } else if (click.isShiftClick() && click.isRightClick()) {
               next = current - settings.bigStep();
            } else if (click.isLeftClick()) {
               next = current + settings.step();
            } else {
               if (!click.isRightClick()) {
                  return;
               }

               next = current - settings.step();
            }

            holder.amount(settings.clamp(next));
            long balance = this.plugin.points() == null ? 0L : this.plugin.points().balance(player.getUniqueId());
            CasinoGuis.renderTreasureMenu(holder, this.plugin.messages(), settings, balance);
            break;
         case 31:
            this.plugin.messages().sendPrefixed(player, "games.treasure.no-opened");
            break;
         case 40:
            this.plugin.treasureGame().startFromMenu(player, holder);
      }
   }

   private void onResource(Player player, GuiHolder holder, int slot) {
      switch (slot) {
         case 18:
            CasinoGuis.openMain(player, this.plugin.messages());
            break;
         case 22:
            this.plugin.resourceGame().play(player, holder);
            break;
         case 26:
            player.closeInventory();
      }
   }
}
