package com.multitool.casino.storage;

import java.time.Instant;
import java.util.UUID;

public record PlayerStats(UUID uuid, String name, long games, long wins, long losses, long wagered, long won, long biggestWin, long lastPlayed) {
   public static PlayerStats empty(UUID uuid, String name) {
      return new PlayerStats(uuid, name, 0L, 0L, 0L, 0L, 0L, 0L, 0L);
   }

   public PlayerStats withGame(String playerName, long stake, long payout) {
      long net = Math.max(0L, payout - stake);
      return new PlayerStats(
         this.uuid,
         playerName,
         this.games + 1L,
         this.wins + (payout > stake ? 1L : 0L),
         this.losses + (payout < stake ? 1L : 0L),
         this.wagered + stake,
         this.won + payout,
         Math.max(this.biggestWin, net),
         Instant.now().toEpochMilli()
      );
   }

   public long netProfit() {
      return this.won - this.wagered;
   }
}
