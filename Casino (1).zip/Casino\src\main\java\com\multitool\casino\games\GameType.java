package com.multitool.casino.games;

import java.util.Locale;
import java.util.Optional;

public enum GameType {
   DIAMOND("diamond", "casino.game.diamond"),
   RESOURCE("resource", "casino.game.resource"),
   TREASURE("treasure", "casino.game.treasure");

   private final String key;
   private final String permission;

   private GameType(String key, String permission) {
      this.key = key;
      this.permission = permission;
   }

   public String key() {
      return this.key;
   }

   public String permission() {
      return this.permission;
   }

   public String messageKey() {
      return "game." + this.key + ".name";
   }

   public static Optional<GameType> byKey(String raw) {
      if (raw == null) {
         return Optional.empty();
      } else {
         String normalized = raw.toLowerCase(Locale.ROOT);

         for (GameType type : values()) {
            if (type.key.equals(normalized)) {
               return Optional.of(type);
            }
         }

         return Optional.empty();
      }
   }
}
