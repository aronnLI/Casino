package com.multitool.casino.utils;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class CooldownManager {
   private final Map<UUID, Long> lastUse = new ConcurrentHashMap<>();
   private volatile int seconds;

   public CooldownManager(int seconds) {
      this.seconds(seconds);
   }

   public void seconds(int seconds) {
      this.seconds = Math.max(0, seconds);
   }

   public int seconds() {
      return this.seconds;
   }

   public long remainingMillis(UUID uuid) {
      Long last = this.lastUse.get(uuid);
      if (last != null && this.seconds != 0) {
         long remaining = last + (long)this.seconds * 1000L - System.currentTimeMillis();
         if (remaining <= 0L) {
            this.lastUse.remove(uuid);
            return 0L;
         } else {
            return remaining;
         }
      } else {
         return 0L;
      }
   }

   public long remainingSeconds(UUID uuid) {
      long remaining = this.remainingMillis(uuid);
      return remaining == 0L ? 0L : (remaining + 999L) / 1000L;
   }

   public void mark(UUID uuid) {
      if (this.seconds != 0) {
         this.lastUse.put(uuid, System.currentTimeMillis());
      }
   }

   public void clear(UUID uuid) {
      this.lastUse.remove(uuid);
   }
}
