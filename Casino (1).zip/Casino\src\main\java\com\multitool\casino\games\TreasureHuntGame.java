package com.multitool.casino.games;

import com.multitool.casino.config.ConfigManager;
import com.multitool.casino.config.Messages;
import com.multitool.casino.economy.PlayerPointsService;
import com.multitool.casino.listeners.gui.CasinoGuis;
import com.multitool.casino.listeners.gui.GuiHolder;
import com.multitool.casino.plugin.CasinoPlugin;
import com.multitool.casino.storage.StatsService;
import com.multitool.casino.utils.ItemBuilder;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ThreadLocalRandom;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

public final class TreasureHuntGame {
   private static final int FIELD_ROWS = 3;
   private static final int FIELD_COLS = 3;
   private static final int FIELD_ROW_START = 1;
   private static final int FIELD_COL_START = 3;
   private static final int[] CONTROL_SLOTS = new int[]{4, 38, 40, 42};
   private static final int[] CELL_SLOTS = buildCells();
   private static final int[] SLOT_INDEX = buildIndex();
   public static final int CELL_COUNT = CELL_SLOTS.length;
   private final CasinoPlugin plugin;
   private final ConfigManager config;
   private final Messages messages;
   private final StatsService stats;
   private final PlayerPointsService points;
   private final Map<UUID, TreasureHuntGame.Session> sessions = new ConcurrentHashMap<>();

   public TreasureHuntGame(
      CasinoPlugin plugin, ConfigManager config, Messages messages, StatsService stats, PlayerPointsService points
   ) {
      this.plugin = plugin;
      this.config = config;
      this.messages = messages;
      this.stats = stats;
      this.points = points;
   }

   private static int[] buildCells() {
      int[] cells = new int[9];
      int index = 0;

      for (int row = 0; row < 3; row++) {
         for (int col = 0; col < 3; col++) {
            cells[index++] = (1 + row) * 9 + 3 + col;
         }
      }

      return cells;
   }

   private static int[] buildIndex() {
      int[] index = new int[45];

      for (int position = 0; position < index.length; position++) {
         index[position] = -1;
      }

      int cell = 0;

      while (cell < CELL_SLOTS.length) {
         index[CELL_SLOTS[cell]] = cell++;
      }

      return index;
   }

   public boolean busy(UUID uuid) {
      TreasureHuntGame.Session session = this.sessions.get(uuid);
      return session != null && !session.finished;
   }

   public void openMenu(Player player) {
      if (this.points == null) {
         this.messages.sendPrefixed(player, "general.economy-missing");
      } else {
         CasinoGuis.openTreasureMenu(player, this.messages, this.config, this.points.balance(player.getUniqueId()));
      }
   }

   public void startFromMenu(Player player, GuiHolder holder) {
      if (this.points == null) {
         this.messages.sendPrefixed(player, "general.economy-missing");
      } else {
         UUID uuid = player.getUniqueId();
         long amount = holder.amount();
         if (this.ready(player, uuid) && this.takeStake(player, uuid, amount)) {
            TreasureHuntGame.Session session = new TreasureHuntGame.Session(uuid, amount, this.config.treasure());
            this.openField(player, session);
         }
      }
   }

   public void click(Player player, GuiHolder holder, int slot, ClickType clickType) {
      TreasureHuntGame.Session session = this.sessions.get(player.getUniqueId());
      if (session != null && session.holder == holder) {
         if (slot == 4) {
            this.leave(player, session);
         } else if (slot == 38) {
            this.changeBet(player, holder, session, clickType);
         } else if (slot == 40) {
            if (!session.finished && !session.opened.isEmpty()) {
               this.cashOut(player, session);
            } else {
               this.messages.sendPrefixed(player, "games.treasure.no-opened");
            }
         } else if (slot != 42) {
            this.dig(player, session, slot);
         } else if (!session.finished) {
            this.messages.sendPrefixed(player, "games.treasure.busy");
         } else {
            this.restart(player, holder, session);
         }
      }
   }

   public void closed(Player player, GuiHolder holder) {
      TreasureHuntGame.Session session = this.sessions.get(player.getUniqueId());
      if (session != null && session.holder == holder) {
         this.sessions.remove(player.getUniqueId());
         if (!session.finished) {
            this.points.give(session.uuid, session.stake);
            this.messages.sendPrefixed(player, "games.treasure.interrupted");
         }
      }
   }

   public void refund(Player player) {
      TreasureHuntGame.Session session = this.sessions.remove(player.getUniqueId());
      if (session != null && !session.finished) {
         this.points.give(session.uuid, session.stake);
      }
   }

   public void shutdown() {
      for (TreasureHuntGame.Session session : List.copyOf(this.sessions.values())) {
         if (this.sessions.remove(session.uuid, session) && !session.finished && this.points != null) {
            this.points.give(session.uuid, session.stake);
         }
      }

      this.sessions.clear();
   }

   private boolean ready(Player player, UUID uuid) {
      TreasureHuntGame.Session existing = this.sessions.get(uuid);
      if (existing != null && !existing.finished) {
         this.messages.sendPrefixed(player, "games.busy");
         return false;
      } else {
         return true;
      }
   }

   private boolean takeStake(Player player, UUID uuid, long amount) {
      ConfigManager.TreasureSettings settings = this.config.treasure();
      if (amount >= settings.minBet() && amount <= settings.maxBet()) {
         long balance = this.points.balance(uuid);
         if (amount <= 0L || balance < amount) {
            this.messages
               .sendPrefixed(
                  player, "games.treasure.not-enough", Messages.p("amount", CasinoGuis.number(amount)), Messages.p("balance", CasinoGuis.number(balance))
               );
            return false;
         } else if (!this.points.take(uuid, amount)) {
            this.messages
               .sendPrefixed(
                  player, "games.treasure.not-enough", Messages.p("amount", CasinoGuis.number(amount)), Messages.p("balance", CasinoGuis.number(balance))
               );
            return false;
         } else {
            long after = this.points.balance(uuid);
            if (after != balance - amount) {
               long restore = balance - after;
               if (restore > 0L) {
                  this.points.give(uuid, restore);
               }

               this.plugin
                  .getLogger()
                  .warning(
                     "PlayerPoints не подтвердил списание ставки у "
                        + player.getName()
                        + ": было "
                        + balance
                        + ", стало "
                        + after
                        + ", ставка "
                        + amount
                        + ". Раунд отменён."
                  );
               this.messages
                  .sendPrefixed(
                     player,
                     "games.treasure.not-enough",
                     Messages.p("amount", CasinoGuis.number(amount)),
                     Messages.p("balance", CasinoGuis.number(this.points.balance(uuid)))
                  );
               return false;
            } else {
               return true;
            }
         }
      } else {
         this.messages
            .sendPrefixed(
               player,
               "games.treasure.limits",
               Messages.p("min", CasinoGuis.number(settings.minBet())),
               Messages.p("max", CasinoGuis.number(settings.maxBet())),
               Messages.p("currency", settings.currency())
            );
         return false;
      }
   }

   private void openField(Player player, TreasureHuntGame.Session session) {
      GuiHolder holder = new GuiHolder(GuiHolder.Type.TREASURE_FIELD);
      Inventory inventory = Bukkit.createInventory(holder, 45, this.messages.component("gui.treasure.field-title"));
      holder.inventory(inventory);
      holder.amount(session.stake);
      session.holder = holder;
      session.bombs = pickBombs(session.settings.bombs());
      this.sessions.put(session.uuid, session);
      this.render(holder, session);
      player.openInventory(inventory);
   }

   private void render(GuiHolder holder, TreasureHuntGame.Session session) {
      Inventory inventory = holder.getInventory();
      ItemStack frame = ItemBuilder.of(Material.BROWN_STAINED_GLASS_PANE).name(Component.text(" ")).hideAll().build();
      ItemStack sand = ItemBuilder.of(Material.SAND)
         .name(this.messages.component("gui.treasure.cell"))
         .lore(this.messages.componentList("gui.treasure.cell-lore"))
         .hideAll()
         .build();
      ItemStack empty = ItemBuilder.of(Material.BROWN_STAINED_GLASS_PANE)
         .name(this.messages.component("gui.treasure.empty"))
         .lore(this.messages.componentList("gui.treasure.empty-lore"))
         .hideAll()
         .build();
      ItemStack bomb = ItemBuilder.of(Material.TNT)
         .name(this.messages.component("gui.treasure.bomb"))
         .lore(this.messages.componentList("gui.treasure.bomb-lore"))
         .hideAll()
         .build();

      for (int slot = 0; slot < 45; slot++) {
         inventory.setItem(slot, frame);
      }

      for (int index = 0; index < CELL_COUNT; index++) {
         int slot = CELL_SLOTS[index];
         if (session.opened.contains(index)) {
            inventory.setItem(slot, empty);
         } else if (session.finished && session.bombs.contains(index)) {
            inventory.setItem(slot, bomb);
         } else {
            inventory.setItem(slot, sand);
         }
      }

      long payout = this.payout(session);
      inventory.setItem(4, CasinoGuis.backItem(this.messages, !session.finished));
      inventory.setItem(38, CasinoGuis.betItem(this.messages, session.settings, holder.amount(), this.points.balance(session.uuid), !session.finished));
      inventory.setItem(40, CasinoGuis.cashoutItem(this.messages, payout, session.settings.currency(), session.finished));
      inventory.setItem(42, CasinoGuis.startItem(this.messages, session.settings, holder.amount(), !session.finished, session.settings.currency()));
   }

   private void dig(Player player, TreasureHuntGame.Session session, int slot) {
      if (!session.finished) {
         int index = slot >= 0 && slot < SLOT_INDEX.length ? SLOT_INDEX[slot] : -1;
         if (index >= 0 && session.opened.add(index)) {
            if (session.bombs.contains(index)) {
               session.opened.remove(index);
               this.lose(player, session);
            } else {
               this.render(session.holder, session);
               if (session.opened.size() >= CELL_COUNT - session.settings.bombs()) {
                  this.cashOut(player, session);
               }
            }
         }
      }
   }

   private void changeBet(Player player, GuiHolder holder, TreasureHuntGame.Session session, ClickType clickType) {
      if (!session.finished) {
         this.messages.sendPrefixed(player, "games.treasure.bet-locked");
      } else {
         ConfigManager.TreasureSettings settings = session.settings;
         long current = holder.amount();
         long next;
         if (clickType == ClickType.DROP || clickType == ClickType.CONTROL_DROP) {
            next = settings.maxBet();
         } else if (clickType.isShiftClick() && clickType.isLeftClick()) {
            next = current + settings.bigStep();
         } else if (clickType.isShiftClick() && clickType.isRightClick()) {
            next = current - settings.bigStep();
         } else if (clickType.isLeftClick()) {
            next = current + settings.step();
         } else {
            if (!clickType.isRightClick()) {
               return;
            }

            next = current - settings.step();
         }

         holder.amount(settings.clamp(next));
         this.render(holder, session);
      }
   }

   private void restart(Player player, GuiHolder holder, TreasureHuntGame.Session previous) {
      if (this.points == null) {
         this.messages.sendPrefixed(player, "general.economy-missing");
      } else {
         long amount = holder.amount();
         if (this.ready(player, previous.uuid) && this.takeStake(player, previous.uuid, amount)) {
            TreasureHuntGame.Session session = new TreasureHuntGame.Session(previous.uuid, amount, this.config.treasure());
            session.holder = holder;
            session.bombs = pickBombs(session.settings.bombs());
            this.sessions.put(session.uuid, session);
            this.render(holder, session);
         }
      }
   }

   private void leave(Player player, TreasureHuntGame.Session session) {
      if (!session.finished) {
         this.messages.sendPrefixed(player, "games.treasure.busy");
      } else {
         this.sessions.remove(player.getUniqueId());
         CasinoGuis.openMain(player, this.messages);
      }
   }

   private void cashOut(Player player, TreasureHuntGame.Session session) {
      double multiplier = session.settings.multiplierFor(session.opened.size(), CELL_COUNT);
      long stake = session.stake;
      long payout = Math.max(0L, Math.round((double)stake * multiplier));
      session.finished = true;
      this.points.give(session.uuid, payout);
      this.stats.record(session.uuid, player.getName(), stake, payout);
      this.render(session.holder, session);
      if (player.isOnline()) {
         this.messages
            .sendPrefixed(
               player,
               "games.treasure.win",
               Messages.p("payout", CasinoGuis.number(payout)),
               Messages.p("multiplier", multiplier(multiplier)),
               Messages.p("currency", session.settings.currency())
            );
      }
   }

   private void lose(Player player, TreasureHuntGame.Session session) {
      long stake = session.stake;
      session.finished = true;
      this.stats.record(session.uuid, player.getName(), stake, 0L);
      this.render(session.holder, session);
      if (player.isOnline()) {
         this.messages
            .sendPrefixed(player, "games.treasure.lose", Messages.p("stake", CasinoGuis.number(stake)), Messages.p("currency", session.settings.currency()));
      }
   }

   private long payout(TreasureHuntGame.Session session) {
      return !session.finished && !session.opened.isEmpty()
         ? Math.max(0L, Math.round((double)session.stake * session.settings.multiplierFor(session.opened.size(), CELL_COUNT)))
         : 0L;
   }

   private static String multiplier(double value) {
      return String.format(Locale.ROOT, "%.2f", Math.max(0.0, value));
   }

   private static Set<Integer> pickBombs(int count) {
      Set<Integer> bombs = new HashSet<>();
      ThreadLocalRandom random = ThreadLocalRandom.current();
      int limit = Math.min(Math.max(1, count), CELL_COUNT - 1);

      while (bombs.size() < limit) {
         bombs.add(random.nextInt(CELL_COUNT));
      }

      return bombs;
   }

   public static final class Session {
      private final UUID uuid;
      private final long stake;
      private final ConfigManager.TreasureSettings settings;
      private final Set<Integer> opened = new HashSet<>();
      private Set<Integer> bombs = Set.of();
      private GuiHolder holder;
      private boolean finished;

      private Session(UUID uuid, long stake, ConfigManager.TreasureSettings settings) {
         this.uuid = uuid;
         this.stake = stake;
         this.settings = settings;
      }
   }
}
