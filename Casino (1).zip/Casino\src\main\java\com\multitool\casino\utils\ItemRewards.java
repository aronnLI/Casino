package com.multitool.casino.utils;

import java.util.Map;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

public final class ItemRewards {
   private ItemRewards() {
   }

   public static void give(Player player, ItemStack stack) {
      if (stack != null && !stack.getType().isAir() && stack.getAmount() > 0) {
         Map<Integer, ItemStack> leftover = player.getInventory().addItem(new ItemStack[]{stack});

         for (ItemStack item : leftover.values()) {
            player.getWorld().dropItemNaturally(player.getLocation(), item);
         }
      }
   }

   public static void giveAmount(Player player, Material material, long amount) {
      long remaining = amount;
      int max = Math.max(1, material.getMaxStackSize());

      while (remaining > 0L) {
         int size = (int)Math.min((long)max, remaining);
         give(player, new ItemStack(material, size));
         remaining -= (long)size;
      }
   }

   public static void giveCopies(Player player, ItemStack template, long total) {
      if (template != null && !template.getType().isAir() && total > 0L) {
         int max = Math.max(1, template.getMaxStackSize());
         long remaining = total;

         while (remaining > 0L) {
            int size = (int)Math.min((long)max, remaining);
            ItemStack copy = template.clone();
            copy.setAmount(size);
            give(player, copy);
            remaining -= (long)size;
         }
      }
   }
}
