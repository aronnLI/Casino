package com.multitool.casino.listeners;

import com.multitool.casino.plugin.CasinoPlugin;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerQuitEvent;

public final class PlayerListener implements Listener {
   private final CasinoPlugin plugin;

   public PlayerListener(CasinoPlugin plugin) {
      this.plugin = plugin;
   }

   @EventHandler
   public void onQuit(PlayerQuitEvent event) {
      this.plugin.diamondGame().refund(event.getPlayer());
      this.plugin.resourceGame().refund(event.getPlayer());
      this.plugin.treasureGame().refund(event.getPlayer());
   }
}
