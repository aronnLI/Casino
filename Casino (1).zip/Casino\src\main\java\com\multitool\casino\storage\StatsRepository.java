package com.multitool.casino.storage;

import java.util.List;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;

public interface StatsRepository extends AutoCloseable {
   CompletableFuture<PlayerStats> update(UUID uuid, String name, long stake, long payout);

   CompletableFuture<PlayerStats> find(UUID uuid, String name);

   CompletableFuture<List<PlayerStats>> top(int limit);

   CompletableFuture<Long> lastResourcePlay(String playerName, String ipAddress);

   CompletableFuture<Void> markResourcePlay(String playerName, String ipAddress, long time);

   void flush();

   @Override
   void close();
}
