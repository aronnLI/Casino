package com.multitool.casino.storage;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;

public final class YamlStatsRepository implements StatsRepository {
   private final Path file;
   private final Logger logger;
   private final ExecutorService executor;
   private final Map<UUID, PlayerStats> data = new ConcurrentHashMap<>();
   private final Map<String, YamlStatsRepository.ResourcePlay> resourcePlays = new ConcurrentHashMap<>();

   public YamlStatsRepository(Path file, Logger logger) {
      this.file = file;
      this.logger = logger;
      this.executor = Executors.newSingleThreadExecutor(Thread.ofVirtual().name("casino-yaml-", 0L).factory());
      this.load();
   }

   private void load() {
      if (Files.exists(this.file)) {
         YamlConfiguration config = YamlConfiguration.loadConfiguration(this.file.toFile());
         ConfigurationSection root = config.getConfigurationSection("players");
         if (root != null) {
            for (String key : root.getKeys(false)) {
               ConfigurationSection node = root.getConfigurationSection(key);
               if (node != null) {
                  try {
                     UUID uuid = UUID.fromString(key);
                     this.data
                        .put(
                           uuid,
                           new PlayerStats(
                              uuid,
                              node.getString("name", key),
                              node.getLong("games"),
                              node.getLong("wins"),
                              node.getLong("losses"),
                              node.getLong("wagered"),
                              node.getLong("won"),
                              node.getLong("biggest-win"),
                              node.getLong("last-played")
                           )
                        );
                  } catch (IllegalArgumentException var7) {
                     this.logger.warning("Пропущена запись статистики с некорректным UUID: " + key);
                  }
               }
            }
         }

         for (Map<?, ?> entry : config.getMapList("resource-cooldown")) {
            Object player = entry.get("player");
            Object ip = entry.get("ip");
            Object time = entry.get("time");
            if (player != null && ip != null && time instanceof Number number) {
               String playerName = String.valueOf(player);
               String ipAddress = String.valueOf(ip);
               this.resourcePlays.put(key(playerName, ipAddress), new YamlStatsRepository.ResourcePlay(playerName, ipAddress, number.longValue()));
            }
         }
      }
   }

   @Override
   public CompletableFuture<PlayerStats> update(UUID uuid, String name, long stake, long payout) {
      PlayerStats updated = this.data.compute(uuid, (key, current) -> {
         PlayerStats base = current == null ? PlayerStats.empty(uuid, name) : current;
         return base.withGame(name, stake, payout);
      });
      this.executor.execute(this::save);
      return CompletableFuture.completedFuture(updated);
   }

   @Override
   public CompletableFuture<PlayerStats> find(UUID uuid, String name) {
      return CompletableFuture.completedFuture(this.data.getOrDefault(uuid, PlayerStats.empty(uuid, name)));
   }

   @Override
   public CompletableFuture<List<PlayerStats>> top(int limit) {
      List<PlayerStats> result = this.data
         .values()
         .stream()
         .sorted(Comparator.comparingLong(PlayerStats::won).reversed())
         .limit((long)Math.max(1, limit))
         .toList();
      return CompletableFuture.completedFuture(result);
   }

   @Override
   public CompletableFuture<Long> lastResourcePlay(String playerName, String ipAddress) {
      String name = playerName == null ? "" : playerName;
      String ip = ipAddress == null ? "" : ipAddress;
      long last = this.resourcePlays
         .values()
         .stream()
         .filter(play -> play.playerName().equalsIgnoreCase(name) || play.ipAddress().equals(ip))
         .mapToLong(YamlStatsRepository.ResourcePlay::time)
         .max()
         .orElse(0L);
      return CompletableFuture.completedFuture(last);
   }

   @Override
   public CompletableFuture<Void> markResourcePlay(String playerName, String ipAddress, long time) {
      String name = playerName == null ? "" : playerName;
      String ip = ipAddress == null ? "" : ipAddress;
      this.resourcePlays.put(key(name, ip), new YamlStatsRepository.ResourcePlay(name, ip, time));
      this.executor.execute(this::save);
      return CompletableFuture.completedFuture(null);
   }

   @Override
   public void flush() {
      this.executor.execute(this::save);
   }

   @Override
   public void close() {
      this.flush();
      this.executor.shutdown();

      try {
         if (!this.executor.awaitTermination(10L, TimeUnit.SECONDS)) {
            this.executor.shutdownNow();
         }
      } catch (InterruptedException var2) {
         Thread.currentThread().interrupt();
      }
   }

   private void save() {
      YamlConfiguration config = new YamlConfiguration();

      for (PlayerStats stats : this.data.values()) {
         String path = "players." + stats.uuid();
         config.set(path + ".name", stats.name());
         config.set(path + ".games", stats.games());
         config.set(path + ".wins", stats.wins());
         config.set(path + ".losses", stats.losses());
         config.set(path + ".wagered", stats.wagered());
         config.set(path + ".won", stats.won());
         config.set(path + ".biggest-win", stats.biggestWin());
         config.set(path + ".last-played", stats.lastPlayed());
      }

      List<Map<String, Object>> plays = this.resourcePlays
         .values()
         .stream()
         .map(play -> Map.<String, Object>of("player", play.playerName(), "ip", play.ipAddress(), "time", play.time()))
         .toList();
      config.set("resource-cooldown", plays);

      try {
         Path parent = this.file.toAbsolutePath().getParent();
         if (parent != null) {
            Files.createDirectories(parent);
         }

         config.save(this.file.toFile());
      } catch (IOException var5) {
         this.logger.log(Level.SEVERE, "Не удалось сохранить " + this.file.getFileName(), (Throwable)var5);
      }
   }

   private static String key(String playerName, String ipAddress) {
      return playerName.toLowerCase(java.util.Locale.ROOT) + "|" + ipAddress;
   }

   private static record ResourcePlay(String playerName, String ipAddress, long time) {
   }
}
