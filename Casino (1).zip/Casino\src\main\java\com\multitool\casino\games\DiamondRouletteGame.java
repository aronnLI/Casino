package com.multitool.casino.games;

import com.multitool.casino.config.ConfigManager;
import com.multitool.casino.config.Messages;
import com.multitool.casino.economy.PlayerPointsService;
import com.multitool.casino.listeners.gui.CasinoGuis;
import com.multitool.casino.listeners.gui.GuiHolder;
import com.multitool.casino.plugin.CasinoPlugin;
import com.multitool.casino.storage.StatsService;
import java.util.Map;
import java.util.UUID;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ThreadLocalRandom;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

public final class DiamondRouletteGame {
   private final CasinoPlugin plugin;
   private final ConfigManager config;
   private final Messages messages;
   private final StatsService stats;
   private final PlayerPointsService points;
   private final Map<UUID, DiamondRouletteGame.SpinTask> pending = new ConcurrentHashMap<>();

   public DiamondRouletteGame(
      CasinoPlugin plugin, ConfigManager config, Messages messages, StatsService stats, PlayerPointsService points
   ) {
      this.plugin = plugin;
      this.config = config;
      this.messages = messages;
      this.stats = stats;
      this.points = points;
   }

   public boolean busy(UUID uuid) {
      return this.pending.containsKey(uuid);
   }

   public void play(Player player, GuiHolder holder) {
      ConfigManager.DiamondSettings settings = this.config.diamond();
      if (this.points == null) {
         this.messages.sendPrefixed(player, "general.economy-missing");
      } else {
         UUID uuid = player.getUniqueId();
         long amount = holder.amount();
         if (this.pending.containsKey(uuid)) {
            this.messages.sendPrefixed(player, "games.busy");
         } else {
            if (amount < settings.minBet()) {
               this.messages.sendPrefixed(player, "errors.below-min", Messages.p("min", settings.minBet()), Messages.p("currency", settings.currency()));
            } else if (amount > settings.maxBet()) {
               this.messages.sendPrefixed(player, "errors.above-max", Messages.p("max", settings.maxBet()), Messages.p("currency", settings.currency()));
            } else {
               long balance = this.points.balance(uuid);
               if (amount <= 0L || balance < amount) {
                  this.messages
                     .sendPrefixed(
                        player,
                        "games.diamond.not-enough",
                        Messages.p("amount", amount),
                        Messages.p("balance", balance),
                        Messages.p("currency", settings.currency())
                     );
               } else if (!this.points.take(uuid, amount)) {
                  this.messages
                     .sendPrefixed(
                        player,
                        "games.diamond.not-enough",
                        Messages.p("amount", amount),
                        Messages.p("balance", balance),
                        Messages.p("currency", settings.currency())
                     );
               } else {
                  long after = this.points.balance(uuid);
                  if (after != balance - amount) {
                     long restore = balance - after;
                     if (restore > 0L) {
                        this.points.give(uuid, restore);
                     }

                     this.plugin
                        .getLogger()
                        .warning(
                           "PlayerPoints не подтвердил списание ставки у "
                              + player.getName()
                              + ": было "
                              + balance
                              + ", стало "
                              + after
                              + ", ставка "
                              + amount
                              + ". Прокрутка отменена."
                        );
                     this.messages
                        .sendPrefixed(
                           player,
                           "games.diamond.not-enough",
                           Messages.p("amount", amount),
                           Messages.p("balance", this.points.balance(uuid)),
                           Messages.p("currency", settings.currency())
                        );
                  } else {
                     ConfigManager.Sector sector = settings.random(ThreadLocalRandom.current());
                     long payout = Math.max(0L, Math.round((double)amount * sector.multiplier()));
                     DiamondRouletteGame.SpinTask task = new DiamondRouletteGame.SpinTask(player, holder, settings, sector, amount, payout);
                     this.pending.put(uuid, task);
                     holder.locked(true);
                     task.runTaskTimer(this.plugin, 1L, (long)settings.tickPeriod());
                  }
               }
            }
         }
      }
   }

   public void refund(Player player) {
      DiamondRouletteGame.SpinTask task = this.pending.remove(player.getUniqueId());
      if (task != null) {
         task.settle();
      }
   }

   public void shutdown() {
      for (Entry<UUID, DiamondRouletteGame.SpinTask> entry : Map.copyOf(this.pending).entrySet()) {
         if (this.pending.remove(entry.getKey(), entry.getValue())) {
            entry.getValue().settle();
         }
      }

      this.pending.clear();
   }

   private final class SpinTask extends BukkitRunnable {
      private final Player player;
      private final GuiHolder holder;
      private final ConfigManager.DiamondSettings settings;
      private final ConfigManager.Sector sector;
      private final long stake;
      private final long payout;
      private final int ticks;
      private final int startOffset;
      private int tick;

      private SpinTask(Player player, GuiHolder holder, ConfigManager.DiamondSettings settings, ConfigManager.Sector sector, long stake, long payout) {
         this.player = player;
         this.holder = holder;
         this.settings = settings;
         this.sector = sector;
         this.stake = stake;
         this.payout = payout;
         this.ticks = settings.animationTicks();
         int size = settings.sectors().size();
         int pointerIndex = 4;
         int winnerIndex = Math.max(0, settings.indexOf(sector));
         int targetOffset = Math.floorMod(winnerIndex - pointerIndex, size);
         this.startOffset = Math.floorMod(targetOffset - this.ticks, size);
      }

      public void run() {
         if (this.tick > this.ticks) {
            this.cancel();
            this.finish();
         } else {
            int size = this.settings.sectors().size();
            CasinoGuis.renderDiamond(this.holder, this.settings, Math.floorMod(this.startOffset + this.tick, size));
            this.tick++;
         }
      }

      private void finish() {
         if (DiamondRouletteGame.this.pending.remove(this.player.getUniqueId(), this)) {
            this.holder.locked(false);
            this.pay();
            if (this.player.isOnline()) {
               boolean win = this.payout > 0L;
               if (win) {
                  DiamondRouletteGame.this.messages
                     .sendPrefixed(
                        this.player,
                        "games.diamond.win",
                        Messages.p("payout", this.payout),
                        Messages.p("multiplier", CasinoGuis.multiplier(this.sector.multiplier())),
                        Messages.p("stake", this.stake),
                        Messages.p("currency", this.settings.currency())
                     );
               } else {
                  DiamondRouletteGame.this.messages
                     .sendPrefixed(
                        this.player,
                        "games.diamond.lose",
                        Messages.p("stake", this.stake),
                        Messages.p("multiplier", CasinoGuis.multiplier(this.sector.multiplier())),
                        Messages.p("currency", this.settings.currency())
                     );
               }

               CasinoGuis.renderDiamondBet(
                  this.holder,
                  DiamondRouletteGame.this.messages,
                  this.settings,
                  DiamondRouletteGame.this.points == null ? 0L : DiamondRouletteGame.this.points.balance(this.player.getUniqueId())
               );
            }
         }
      }

      private void settle() {
         this.cancel();
         this.pay();
      }

      private void pay() {
         if (DiamondRouletteGame.this.points != null && this.payout > 0L) {
            DiamondRouletteGame.this.points.give(this.player.getUniqueId(), this.payout);
         }

         DiamondRouletteGame.this.stats.record(this.player.getUniqueId(), this.player.getName(), this.stake, this.payout);
      }
   }
}
