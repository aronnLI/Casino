package com.multitool.casino.commands;

import com.multitool.casino.config.Messages;
import com.multitool.casino.games.GameType;
import com.multitool.casino.listeners.gui.CasinoGuis;
import com.multitool.casino.plugin.CasinoPlugin;
import com.multitool.casino.storage.PlayerStats;
import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.UUID;
import java.util.logging.Level;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Player;

public final class CasinoCommand implements TabExecutor {
   private static final List<String> SUBCOMMANDS = List.of("help", "menu", "diamond", "resource", "treasure", "stats", "top", "reload");
   private static final DateTimeFormatter DATE_FORMAT = DateTimeFormatter.ofPattern("dd.MM.yyyy HH:mm");
   private final CasinoPlugin plugin;

   public CasinoCommand(CasinoPlugin plugin) {
      this.plugin = plugin;
   }

   public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
      Messages messages = this.plugin.messages();
      if (!sender.hasPermission("casino.use")) {
         messages.sendPrefixed(sender, "general.no-permission");
         return true;
      } else {
         try {
            return this.dispatch(sender, args);
         } catch (Throwable var7) {
            this.plugin.getLogger().log(Level.SEVERE, "Ошибка выполнения команды /" + label + " " + String.join(" ", args), var7);
            messages.sendPrefixed(sender, "general.command-error");
            if (sender.hasPermission("casino.admin")) {
               sender.sendMessage(Component.text("Casino: " + var7.getClass().getName() + ": " + var7.getMessage(), NamedTextColor.DARK_RED));
            }

            return true;
         }
      }
   }

   private boolean dispatch(CommandSender sender, String[] args) {
      Messages messages = this.plugin.messages();
      if (args.length == 0) {
         this.menu(sender);
         return true;
      } else {
         String var4 = args[0].toLowerCase(Locale.ROOT);
         switch (var4) {
            case "help":
               this.help(sender);
               break;
            case "menu":
               this.menu(sender);
               break;
            case "diamond":
               this.openGame(sender, GameType.DIAMOND);
               break;
            case "resource":
               this.openGame(sender, GameType.RESOURCE);
               break;
            case "treasure":
               this.openGame(sender, GameType.TREASURE);
               break;
            case "stats":
               this.stats(sender, args);
               break;
            case "top":
               this.top(sender);
               break;
            case "reload":
               this.reload(sender);
               break;
            default:
               if (this.isKnownPlayer(args[0])) {
                  this.stats(sender, new String[]{"stats", args[0]});
               } else {
                  messages.sendPrefixed(sender, "general.unknown-subcommand");
               }
         }

         return true;
      }
   }

   public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
      if (args.length == 1) {
         List<String> options = new ArrayList<>(SUBCOMMANDS);
         options.addAll(Bukkit.getOnlinePlayers().stream().map(Player::getName).toList());
         return filter(options, args[0]);
      } else {
         return args.length == 2 && args[0].equalsIgnoreCase("stats")
            ? filter(Bukkit.getOnlinePlayers().stream().<String>map(Player::getName).toList(), args[1])
            : List.of();
      }
   }

   private void menu(CommandSender sender) {
      if (sender instanceof Player player) {
         CasinoGuis.openMain(player, this.plugin.messages());
      } else {
         this.plugin.messages().sendPrefixed(sender, "general.player-only");
      }
   }

   private void openGame(CommandSender sender, GameType type) {
      Messages messages = this.plugin.messages();
      if (sender instanceof Player player) {
         if (!player.hasPermission(type.permission())) {
            messages.sendPrefixed(player, "general.no-permission");
         } else if (type == GameType.TREASURE) {
            this.plugin.treasureGame().openMenu(player);
         } else {
            if (type == GameType.DIAMOND) {
               if (this.plugin.points() == null) {
                  messages.sendPrefixed(player, "general.economy-missing");
                  return;
               }

               CasinoGuis.openDiamond(player, messages, this.plugin.configManager(), this.plugin.points().balance(player.getUniqueId()));
            } else {
               this.plugin.resourceCooldown().gate(player, () -> CasinoGuis.openResource(player, messages, this.plugin.configManager()));
            }
         }
      } else {
         messages.sendPrefixed(sender, "general.player-only");
      }
   }

   private void help(CommandSender sender) {
      Messages messages = this.plugin.messages();
      messages.send(sender, "help.header");
      messages.sendList(sender, "help.lines");
      messages.send(sender, "help.footer");
   }

   private void stats(CommandSender sender, String[] args) {
      Messages messages = this.plugin.messages();
      UUID target;
      String name;
      if (args.length >= 2) {
         Player online = Bukkit.getPlayerExact(args[1]);
         if (online != null) {
            target = online.getUniqueId();
            name = online.getName();
         } else {
            OfflinePlayer cached = Bukkit.getOfflinePlayerIfCached(args[1]);
            if (cached == null) {
               messages.sendPrefixed(sender, "general.player-not-found", Messages.p("player", args[1]));
               return;
            }

            target = cached.getUniqueId();
            String cachedName = cached.getName();
            name = cachedName == null ? args[1] : cachedName;
         }
      } else {
         if (!(sender instanceof Player player)) {
            messages.sendPrefixed(sender, "general.player-only");
            return;
         }

         target = player.getUniqueId();
         name = player.getName();
      }

      String fallbackName = name;
      this.plugin.statsService().get(target, name).thenAccept(stats -> this.sync(() -> this.sendStats(sender, stats, fallbackName)));
   }

   private void sendStats(CommandSender sender, PlayerStats stats, String fallbackName) {
      Messages messages = this.plugin.messages();
      String displayName = stats.name() != null && !stats.name().isBlank() ? stats.name() : fallbackName;
      Component last = (Component)(stats.lastPlayed() == 0L
         ? messages.component("stats.never")
         : Component.text(Instant.ofEpochMilli(stats.lastPlayed()).atZone(ZoneId.systemDefault()).format(DATE_FORMAT)));
      messages.send(sender, "stats.header", Messages.p("player", displayName));
      messages.send(sender, "stats.games", Messages.p("games", stats.games()), Messages.p("wins", stats.wins()), Messages.p("losses", stats.losses()));
      messages.send(sender, "stats.items", Messages.p("wagered", stats.wagered()), Messages.p("won", stats.won()));
      long profit = stats.netProfit();
      messages.send(sender, profit >= 0L ? "stats.profit-positive" : "stats.profit-negative", Messages.p("profit", Math.abs(profit)));
      messages.send(sender, "stats.biggest", Messages.p("biggest", stats.biggestWin()));
      messages.send(sender, "stats.last", Messages.p("last", last));
   }

   private void top(CommandSender sender) {
      Messages messages = this.plugin.messages();
      this.plugin
         .statsService()
         .top(10)
         .thenAccept(
            list -> this.sync(
                  () -> {
                     messages.send(sender, "top.header");
                     if (list.isEmpty()) {
                        messages.send(sender, "top.empty");
                     } else {
                        int place = 1;

                        for (PlayerStats stats : list) {
                           long profit = stats.netProfit();
                           String signed = profit >= 0L ? "+" + profit : String.valueOf(profit);
                           messages.send(
                              sender,
                              "top.line",
                              Messages.p("place", place++),
                              Messages.p("player", stats.name()),
                              Messages.p("won", stats.won()),
                              Messages.p("profit", signed)
                           );
                        }

                        messages.send(sender, "top.footer");
                     }
                  }
               )
         );
   }

   private void reload(CommandSender sender) {
      Messages messages = this.plugin.messages();
      if (!sender.hasPermission("casino.admin")) {
         messages.sendPrefixed(sender, "general.no-permission");
      } else {
         this.plugin.reloadPlugin();
         messages.sendPrefixed(sender, "general.reloaded");
      }
   }

   private void sync(Runnable runnable) {
      Bukkit.getScheduler().runTask(this.plugin, runnable);
   }

   private boolean isKnownPlayer(String raw) {
      return Bukkit.getPlayerExact(raw) != null || Bukkit.getOfflinePlayerIfCached(raw) != null;
   }

   private static List<String> filter(List<String> options, String prefix) {
      String normalized = prefix.toLowerCase(Locale.ROOT);
      return options.stream().filter(option -> option.toLowerCase(Locale.ROOT).startsWith(normalized)).toList();
   }
}
