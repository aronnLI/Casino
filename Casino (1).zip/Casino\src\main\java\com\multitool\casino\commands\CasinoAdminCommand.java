package com.multitool.casino.commands;

import com.multitool.casino.config.Messages;
import com.multitool.casino.plugin.CasinoPlugin;
import java.util.List;
import java.util.Locale;
import java.util.logging.Level;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;

public final class CasinoAdminCommand implements TabExecutor {
   private static final List<String> SUBCOMMANDS = List.of("reload", "help");
   private final CasinoPlugin plugin;

   public CasinoAdminCommand(CasinoPlugin plugin) {
      this.plugin = plugin;
   }

   public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
      Messages messages = this.plugin.messages();
      if (!sender.hasPermission("casino.admin")) {
         messages.sendPrefixed(sender, "general.no-permission");
         return true;
      }

      try {
         String subcommand = args.length == 0 ? "help" : args[0].toLowerCase(Locale.ROOT);
         switch (subcommand) {
            case "reload" -> this.reload(sender);
            case "help" -> this.help(sender);
            default -> messages.sendPrefixed(sender, "general.unknown-subcommand");
         }
      } catch (Throwable error) {
         this.plugin.getLogger().log(Level.SEVERE, "Ошибка выполнения команды /" + label + " " + String.join(" ", args), error);
         messages.sendPrefixed(sender, "general.command-error");
      }

      return true;
   }

   public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
      if (!sender.hasPermission("casino.admin")) {
         return List.of();
      }

      if (args.length == 1) {
         return SUBCOMMANDS.stream().filter(option -> option.startsWith(args[0].toLowerCase(Locale.ROOT))).toList();
      }

      return List.of();
   }

   private void reload(CommandSender sender) {
      Messages messages = this.plugin.messages();
      this.plugin.reloadPlugin();
      messages.sendPrefixed(sender, "general.reloaded");
      this.plugin.getLogger().info("Конфигурация перезагружена командой /casinoadmin reload (" + sender.getName() + ").");
   }

   private void help(CommandSender sender) {
      Messages messages = this.plugin.messages();
      messages.sendPrefixed(sender, "admin.help.header");
      messages.sendList(sender, "admin.help.lines");
   }
}
