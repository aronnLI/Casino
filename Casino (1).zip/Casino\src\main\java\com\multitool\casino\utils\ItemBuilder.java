package com.multitool.casino.utils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import net.kyori.adventure.text.Component;
import org.bukkit.Material;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public final class ItemBuilder {
   private final ItemStack item;
   private final ItemMeta meta;

   private ItemBuilder(Material material) {
      this.item = new ItemStack(material);
      this.meta = this.item.getItemMeta();
   }

   public static ItemBuilder of(Material material) {
      return new ItemBuilder(material);
   }

   public ItemBuilder name(Component name) {
      if (this.meta != null) {
         this.meta.displayName(name);
      }

      return this;
   }

   public ItemBuilder lore(Component... lines) {
      return this.lore(Arrays.asList(lines));
   }

   public ItemBuilder lore(List<Component> lines) {
      if (this.meta != null) {
         this.meta.lore(new ArrayList<>(lines));
      }

      return this;
   }

   public ItemBuilder amount(int amount) {
      this.item.setAmount(Math.max(1, Math.min(this.item.getMaxStackSize(), amount)));
      return this;
   }

   public ItemBuilder glow(boolean glow) {
      if (this.meta != null) {
         this.meta.setEnchantmentGlintOverride(glow);
      }

      return this;
   }

   public ItemBuilder flags(ItemFlag... flags) {
      if (this.meta != null) {
         this.meta.addItemFlags(flags);
      }

      return this;
   }

   public ItemBuilder hideAll() {
      return this.flags(ItemFlag.values());
   }

   public ItemBuilder maxStack() {
      this.item.setAmount(this.item.getMaxStackSize());
      return this;
   }

   public ItemStack build() {
      if (this.meta != null) {
         this.item.setItemMeta(this.meta);
      }

      return this.item;
   }
}
