package com.multitool.casino.listeners.gui;

import com.multitool.casino.config.ConfigManager;
import com.multitool.casino.config.Messages;
import com.multitool.casino.games.TreasureHuntGame;
import com.multitool.casino.utils.ItemBuilder;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

public final class CasinoGuis {
   public static final int SIZE = 27;
   public static final int BUTTON_BACK = 18;
   public static final int BUTTON_PLAY = 22;
   public static final int BUTTON_CLOSE = 26;
   public static final int DIAMOND_SIZE = 45;
   public static final int DIAMOND_WHEEL_START = 18;
   public static final int DIAMOND_WHEEL_SIZE = 9;
   public static final int DIAMOND_POINTER = 22;
   public static final int DIAMOND_LANE_TOP = 13;
   public static final int DIAMOND_LANE_BOTTOM = 31;
   public static final int DIAMOND_BET = 39;
   public static final int DIAMOND_SPIN = 40;
   public static final int RESOURCE_INPUT = 13;
   public static final int TREASURE_SIZE = 45;
   public static final int MAIN_DIAMOND = 21;
   public static final int MAIN_RESOURCE = 22;
   public static final int MAIN_TREASURE = 23;
   public static final int TREASURE_MENU_BET = 13;
   public static final int TREASURE_MENU_RULES = 21;
   public static final int TREASURE_MENU_BALANCE = 22;
   public static final int TREASURE_MENU_CASHOUT = 31;
   public static final int TREASURE_MENU_START = 40;
   public static final int TREASURE_BACK = 4;
   public static final int TREASURE_BET = 38;
   public static final int TREASURE_CASHOUT = 40;
   public static final int TREASURE_START = 42;
   private static final String[] TREASURE_MENU_PATTERN = new String[]{"DDLLLLLDD", "DLLLLLLLD", "DLLLLLLLD", "DLLLLLLLD", "DDLLLLLDD"};

   private CasinoGuis() {
   }

   public static void openMain(Player player, Messages messages) {
      GuiHolder holder = new GuiHolder(GuiHolder.Type.MAIN);
      Inventory inventory = Bukkit.createInventory(holder, 45, messages.component("gui.main.title"));
      holder.inventory(inventory);
      fillPattern(inventory);
      inventory.setItem(
         21,
         ItemBuilder.of(Material.DIAMOND)
            .name(messages.component("gui.main.diamond.name"))
            .lore(messages.componentList("gui.main.diamond.lore"))
            .hideAll()
            .build()
      );
      inventory.setItem(
         22,
         ItemBuilder.of(Material.CHEST)
            .name(messages.component("gui.main.resource.name"))
            .lore(messages.componentList("gui.main.resource.lore"))
            .hideAll()
            .build()
      );
      inventory.setItem(
         23,
         ItemBuilder.of(Material.SAND)
            .name(messages.component("gui.main.treasure.name"))
            .lore(messages.componentList("gui.main.treasure.lore"))
            .hideAll()
            .build()
      );
      player.openInventory(inventory);
   }

   public static GuiHolder openDiamond(Player player, Messages messages, ConfigManager config, long balance) {
      ConfigManager.DiamondSettings settings = config.diamond();
      GuiHolder holder = new GuiHolder(GuiHolder.Type.DIAMOND);
      Inventory inventory = Bukkit.createInventory(holder, 45, messages.component("gui.diamond.title"));
      holder.inventory(inventory);
      holder.amount(settings.minBet());
      fillDiamond(inventory);
      renderDiamondBet(holder, messages, settings, balance);
      renderDiamond(holder, settings, 0);
      player.openInventory(inventory);
      return holder;
   }

   private static void fillDiamond(Inventory inventory) {
      ItemStack base = ItemBuilder.of(Material.LIME_STAINED_GLASS_PANE).name(Component.text(" ")).build();
      ItemStack lane = ItemBuilder.of(Material.YELLOW_STAINED_GLASS_PANE).name(Component.text(" ")).build();

      for (int slot = 0; slot < inventory.getSize(); slot++) {
         inventory.setItem(slot, base);
      }

      inventory.setItem(13, lane);
      inventory.setItem(31, lane);
   }

   public static void renderDiamondBet(GuiHolder holder, Messages messages, ConfigManager.DiamondSettings settings, long balance) {
      Inventory inventory = holder.getInventory();
      inventory.setItem(
         39,
         ItemBuilder.of(Material.CHEST)
            .name(messages.component("gui.diamond.bet-name", Messages.p("amount", holder.amount()), Messages.p("currency", settings.currency())))
            .lore(
               messages.componentList(
                  "gui.diamond.bet-lore",
                  Messages.p("min", settings.minBet()),
                  Messages.p("max", settings.maxBet()),
                  Messages.p("balance", balance),
                  Messages.p("currency", settings.currency())
               )
            )
            .glow(true)
            .build()
      );
      inventory.setItem(
         40,
         ItemBuilder.of(Material.SUNFLOWER)
            .name(messages.component("gui.diamond.spin-name"))
            .lore(messages.componentList("gui.diamond.spin-lore", Messages.p("amount", holder.amount()), Messages.p("currency", settings.currency())))
            .glow(true)
            .build()
      );
   }

   public static void renderDiamond(GuiHolder holder, ConfigManager.DiamondSettings settings, int offset) {
      Inventory inventory = holder.getInventory();
      List<ConfigManager.Sector> sectors = settings.sectors();
      int size = sectors.size();

      for (int index = 0; index < 9; index++) {
         ConfigManager.Sector sector = sectors.get(Math.floorMod(offset + index, size));
         boolean pointer = 18 + index == 22;
         inventory.setItem(18 + index, ItemBuilder.of(sector.material()).name(sector.display()).glow(pointer).hideAll().build());
      }
   }

   public static GuiHolder openTreasureMenu(Player player, Messages messages, ConfigManager config, long balance) {
      ConfigManager.TreasureSettings settings = config.treasure();
      GuiHolder holder = new GuiHolder(GuiHolder.Type.TREASURE_MENU);
      Inventory inventory = Bukkit.createInventory(holder, 45, messages.component("gui.treasure.menu-title"));
      holder.inventory(inventory);
      holder.amount(settings.minBet());
      fillPattern(inventory);
      renderTreasureMenu(holder, messages, settings, balance);
      player.openInventory(inventory);
      return holder;
   }

   public static void renderTreasureMenu(GuiHolder holder, Messages messages, ConfigManager.TreasureSettings settings, long balance) {
      Inventory inventory = holder.getInventory();
      long amount = holder.amount();
      inventory.setItem(13, betItem(messages, settings, amount, balance, false));
      inventory.setItem(
         21,
         ItemBuilder.of(Material.BOOK)
            .name(messages.component("gui.treasure.rules-name"))
            .lore(
               messages.componentList(
                  "gui.treasure.rules-lore",
                  Messages.p("bombs", settings.bombs()),
                  Messages.p("cells", TreasureHuntGame.CELL_COUNT),
                  Messages.p("min", number(settings.minBet())),
                  Messages.p("max", number(settings.maxBet())),
                  Messages.p("currency", settings.currency())
               )
            )
            .hideAll()
            .build()
      );
      inventory.setItem(
         22,
         ItemBuilder.of(Material.SUNFLOWER)
            .name(messages.component("gui.treasure.balance-name"))
            .lore(
               messages.componentList(
                  "gui.treasure.balance-lore",
                  Messages.p("balance", number(balance)),
                  Messages.p("currency", settings.currency()),
                  Messages.p("max", number(settings.maxBet()))
               )
            )
            .hideAll()
            .build()
      );
      inventory.setItem(31, cashoutItem(messages, 0L, settings.currency(), true));
      inventory.setItem(40, startItem(messages, settings, amount, false, settings.currency()));
   }

   public static ItemStack betItem(Messages messages, ConfigManager.TreasureSettings settings, long amount, long balance, boolean locked) {
      List<Component> lore = locked
         ? messages.componentList("gui.treasure.bet-locked")
         : messages.componentList(
            "gui.treasure.bet-lore",
            Messages.p("amount", number(amount)),
            Messages.p("balance", number(balance)),
            Messages.p("currency", settings.currency()),
            Messages.p("step", number(settings.step())),
            Messages.p("big", number(settings.bigStep()))
         );
      return ItemBuilder.of(Material.CHEST).name(messages.component("gui.treasure.bet-name")).lore(lore).hideAll().build();
   }

   public static ItemStack startItem(Messages messages, ConfigManager.TreasureSettings settings, long amount, boolean inGame, String currency) {
      List<Component> lore = inGame
         ? messages.componentList("gui.treasure.start-busy")
         : messages.componentList("gui.treasure.start-lore", Messages.p("amount", number(amount)), Messages.p("currency", currency));
      return ItemBuilder.of(Material.ARROW).name(messages.component("gui.treasure.start-name")).lore(lore).glow(!inGame).hideAll().build();
   }

   public static ItemStack cashoutItem(Messages messages, long payout, String currency, boolean unavailable) {
      List<Component> lore = !unavailable && payout > 0L
         ? messages.componentList("gui.treasure.cashout-lore", Messages.p("payout", number(payout)), Messages.p("currency", currency))
         : messages.componentList("gui.treasure.cashout-empty");
      return ItemBuilder.of(Material.BUCKET)
         .name(messages.component("gui.treasure.cashout-name"))
         .lore(lore)
         .glow(!unavailable && payout > 0L)
         .hideAll()
         .build();
   }

   public static ItemStack backItem(Messages messages, boolean inGame) {
      List<Component> lore = inGame ? messages.componentList("gui.treasure.back-locked") : messages.componentList("gui.treasure.back-lore");
      return ItemBuilder.of(Material.BUCKET).name(messages.component("gui.treasure.back-name")).lore(lore).hideAll().build();
   }

   private static void fillPattern(Inventory inventory) {
      ItemStack dark = ItemBuilder.of(Material.BROWN_STAINED_GLASS_PANE).name(Component.text(" ")).hideAll().build();
      ItemStack light = ItemBuilder.of(Material.ORANGE_STAINED_GLASS_PANE).name(Component.text(" ")).hideAll().build();

      for (int row = 0; row < TREASURE_MENU_PATTERN.length; row++) {
         String pattern = TREASURE_MENU_PATTERN[row];

         for (int column = 0; column < 9; column++) {
            inventory.setItem(row * 9 + column, pattern.charAt(column) == 'D' ? dark : light);
         }
      }
   }

   public static String number(long value) {
      return String.format(Locale.ROOT, "%,d", value);
   }

   public static GuiHolder openResource(Player player, Messages messages, ConfigManager config) {
      GuiHolder holder = new GuiHolder(GuiHolder.Type.RESOURCE);
      holder.inputSlot(13);
      Inventory inventory = Bukkit.createInventory(holder, 27, messages.component("gui.resource.title"));
      holder.inventory(inventory);
      fill(inventory);
      inventory.setItem(13, null);
      List<Component> payoutLore = new ArrayList<>();

      for (ConfigManager.ResourceMultiplier multiplier : config.resource().multipliers()) {
         payoutLore.add(multiplier.display());
      }

      inventory.setItem(15, ItemBuilder.of(Material.GOLD_INGOT).name(messages.component("gui.resource.payout-name")).lore(payoutLore).build());
      inventory.setItem(
         22,
         ItemBuilder.of(Material.LIME_CONCRETE)
            .name(messages.component("gui.resource.play"))
            .lore(messages.componentList("gui.resource.play-lore"))
            .glow(true)
            .build()
      );
      inventory.setItem(18, button(Material.ARROW, messages.component("gui.back")));
      inventory.setItem(26, button(Material.BARRIER, messages.component("gui.close")));
      player.openInventory(inventory);
      return holder;
   }

   public static void setResultButton(GuiHolder holder, Material material, Component name) {
      holder.getInventory().setItem(22, ItemBuilder.of(material).name(name).build());
   }

   public static ItemStack button(Material material, Component name, Component... lore) {
      return ItemBuilder.of(material).name(name).lore(lore).build();
   }

   public static void fill(Inventory inventory) {
      ItemStack filler = ItemBuilder.of(Material.GRAY_STAINED_GLASS_PANE).name(Component.text(" ", NamedTextColor.DARK_GRAY)).build();

      for (int slot = 0; slot < inventory.getSize(); slot++) {
         inventory.setItem(slot, filler);
      }
   }

   public static String multiplier(double value) {
      return value == Math.rint(value) ? String.valueOf((long)value) : String.valueOf(value);
   }
}
