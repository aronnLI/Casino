package com.multitool.casino.games;

import com.multitool.casino.config.Messages;
import com.multitool.casino.plugin.CasinoPlugin;
import java.net.InetSocketAddress;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Level;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

public final class ResourceRouletteCooldown {
   private final CasinoPlugin plugin;
   private final Set<UUID> pending = ConcurrentHashMap.newKeySet();

   public ResourceRouletteCooldown(CasinoPlugin plugin) {
      this.plugin = plugin;
   }

   public void gate(Player player, Runnable onAllowed) {
      this.check(player, false, onAllowed);
   }

   public void gateAndMark(Player player, Runnable onAllowed) {
      this.check(player, true, onAllowed);
   }

   private void check(Player player, boolean mark, Runnable onAllowed) {
      int hours = this.plugin.configManager().resource().cooldownHours();
      if (hours <= 0) {
         this.runOnMain(onAllowed);
         return;
      }

      String ip = address(player);
      if (ip == null) {
         this.runOnMain(onAllowed);
         return;
      }

      UUID uuid = player.getUniqueId();
      String name = player.getName();
      if (!this.pending.add(uuid)) {
         return;
      }

      long now = System.currentTimeMillis();
      long window = hours * 3_600_000L;
      this.plugin
         .statsService()
         .lastResourcePlay(name, ip)
         .whenComplete(
            (last, error) -> Bukkit.getScheduler()
               .runTask(
                  this.plugin,
                  () -> {
                     this.pending.remove(uuid);
                     if (!player.isOnline()) {
                        return;
                     }

                     if (error != null) {
                        this.plugin
                           .getLogger()
                           .log(Level.WARNING, "Не удалось проверить IP-кулдаун ресурсной рулетки для " + name, error);
                        onAllowed.run();
                        return;
                     }

                     long lastPlay = last == null ? 0L : last;
                     long elapsed = now - lastPlay;
                     if (lastPlay > 0L && elapsed < window) {
                        this.plugin
                           .messages()
                           .sendPrefixed(
                              player,
                              "errors.resource-ip-cooldown",
                              Messages.p("hours", hours),
                              Messages.p("time", format(window - elapsed))
                           );
                        return;
                     }

                     if (mark) {
                        this.plugin.statsService().markResourcePlay(name, ip, now);
                     }

                     onAllowed.run();
                  }
               )
         );
   }

   private void runOnMain(Runnable action) {
      if (Bukkit.isPrimaryThread()) {
         action.run();
      } else {
         Bukkit.getScheduler().runTask(this.plugin, action);
      }
   }

   private static String address(Player player) {
      InetSocketAddress socket = player.getAddress();
      return socket == null || socket.getAddress() == null ? null : socket.getAddress().getHostAddress();
   }

   private static String format(long millis) {
      long totalMinutes = Math.max(1L, millis / 60_000L);
      long hours = totalMinutes / 60L;
      long minutes = totalMinutes % 60L;
      return hours > 0L ? hours + " ч " + minutes + " мин" : minutes + " мин";
   }
}
