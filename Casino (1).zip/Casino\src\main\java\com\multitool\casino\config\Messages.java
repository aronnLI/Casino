package com.multitool.casino.config;

import com.multitool.casino.plugin.CasinoPlugin;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.text.minimessage.tag.resolver.Placeholder;
import net.kyori.adventure.text.minimessage.tag.resolver.TagResolver;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.YamlConfiguration;

public final class Messages {
   private static final MiniMessage MINI = MiniMessage.miniMessage();
   private final CasinoPlugin plugin;
   private YamlConfiguration config = new YamlConfiguration();
   private Component prefix = Component.empty();

   public Messages(CasinoPlugin plugin) {
      this.plugin = plugin;
   }

   public void reload() {
      File file = new File(this.plugin.getDataFolder(), "messages.yml");
      if (!file.exists()) {
         this.plugin.saveResource("messages.yml", false);
      }

      YamlConfiguration loaded;
      try {
         loaded = YamlConfiguration.loadConfiguration(file);
      } catch (IllegalArgumentException var6) {
         this.plugin.getLogger().severe("Не удалось прочитать messages.yml: " + var6.getMessage());
         loaded = new YamlConfiguration();
      }

      YamlConfiguration jarDefaults = this.bundledDefaults();
      if (jarDefaults != null) {
         loaded.setDefaults(jarDefaults);
         loaded.options().copyDefaults(true);

         try {
            loaded.save(file);
         } catch (IOException var5) {
            this.plugin.getLogger().warning("Не удалось обновить messages.yml новыми ключами: " + var5.getMessage());
         }
      }

      this.config = loaded;
      this.prefix = MINI.deserialize(this.config.getString("prefix", ""));
   }

   private YamlConfiguration bundledDefaults() {
      try {
         YamlConfiguration var2;
         try (InputStream stream = this.plugin.getResource("messages.yml")) {
            if (stream == null) {
               return null;
            }

            var2 = YamlConfiguration.loadConfiguration(new InputStreamReader(stream, StandardCharsets.UTF_8));
         }

         return var2;
      } catch (IOException var6) {
         this.plugin.getLogger().warning("Не удалось прочитать messages.yml из jar: " + var6.getMessage());
         return null;
      }
   }

   public Component component(String key, TagResolver... resolvers) {
      String raw = this.config.getString(key);
      return (Component)(raw == null ? Component.text("<нет сообщения: " + key + ">", NamedTextColor.RED) : MINI.deserialize(raw, resolvers));
   }

   public List<Component> componentList(String key, TagResolver... resolvers) {
      List<String> raw = this.config.getStringList(key);
      List<Component> result = new ArrayList<>(raw.size());

      for (String line : raw) {
         result.add(MINI.deserialize(line, resolvers));
      }

      return result;
   }

   public List<String> stringList(String key) {
      return this.config.getStringList(key);
   }

   public void send(CommandSender sender, String key, TagResolver... resolvers) {
      sender.sendMessage(this.component(key, resolvers));
   }

   public void sendPrefixed(CommandSender sender, String key, TagResolver... resolvers) {
      sender.sendMessage(this.prefix.append(this.component(key, resolvers)));
   }

   public void sendList(CommandSender sender, String key, TagResolver... resolvers) {
      for (Component line : this.componentList(key, resolvers)) {
         sender.sendMessage(line);
      }
   }

   public Component prefix() {
      return this.prefix;
   }

   public static TagResolver p(String key, Object value) {
      return Placeholder.unparsed(key, String.valueOf(value));
   }

   public static TagResolver p(String key, Component value) {
      return Placeholder.component(key, value);
   }
}
