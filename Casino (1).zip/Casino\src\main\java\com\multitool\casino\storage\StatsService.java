package com.multitool.casino.storage;

import com.multitool.casino.plugin.CasinoPlugin;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import org.bukkit.scheduler.BukkitTask;

public final class StatsService {
   private final CasinoPlugin plugin;
   private final StatsRepository repository;
   private final Map<UUID, PlayerStats> cache = new ConcurrentHashMap<>();
   private BukkitTask flushTask;

   public StatsService(CasinoPlugin plugin, StatsRepository repository) {
      this.plugin = plugin;
      this.repository = repository;
   }

   public void start() {
      int interval = this.plugin.configManager().storage().saveIntervalSeconds();
      this.flushTask = this.plugin
         .getServer()
         .getScheduler()
         .runTaskTimerAsynchronously(this.plugin, this.repository::flush, (long)interval * 20L, (long)interval * 20L);
   }

   public void record(UUID uuid, String name, long stake, long payout) {
      this.repository.update(uuid, name, stake, payout).thenAccept(updated -> this.cache.put(uuid, updated));
   }

   public CompletableFuture<PlayerStats> get(UUID uuid, String name) {
      PlayerStats cached = this.cache.get(uuid);
      return cached != null ? CompletableFuture.completedFuture(cached) : this.repository.find(uuid, name).thenApply(stats -> {
         this.cache.put(uuid, stats);
         return (PlayerStats)stats;
      });
   }

   public CompletableFuture<List<PlayerStats>> top(int limit) {
      return this.repository.top(limit);
   }

   public CompletableFuture<Long> lastResourcePlay(String playerName, String ipAddress) {
      return this.repository.lastResourcePlay(playerName, ipAddress);
   }

   public CompletableFuture<Void> markResourcePlay(String playerName, String ipAddress, long time) {
      return this.repository.markResourcePlay(playerName, ipAddress, time);
   }

   public void close() {
      if (this.flushTask != null) {
         this.flushTask.cancel();
         this.flushTask = null;
      }

      this.repository.close();
   }
}
