package com.multitool.casino.config;

import com.multitool.casino.plugin.CasinoPlugin;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ThreadLocalRandom;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public final class ConfigManager {
   private static final MiniMessage MINI = MiniMessage.miniMessage();
   private static final PlainTextComponentSerializer PLAIN = PlainTextComponentSerializer.plainText();
   private final CasinoPlugin plugin;
   private volatile ConfigManager.StorageSettings storage;
   private volatile ConfigManager.DiamondSettings diamond;
   private volatile ConfigManager.ResourceSettings resource;
   private volatile ConfigManager.TreasureSettings treasure;
   private volatile int cooldownSeconds;

   public ConfigManager(CasinoPlugin plugin) {
      this.plugin = plugin;
      this.reload();
   }

   public void reload() {
      this.plugin.reloadConfig();
      FileConfiguration config = this.plugin.getConfig();
      if (!config.contains("resource-roulette.blocked-items")) {
         this.plugin
            .getLogger()
            .info("В config.yml нет секции resource-roulette.blocked-items — список запрещённых предметов пуст. Добавьте её, чтобы блокировать предметы по названию.");
      }

      this.cooldownSeconds = Math.max(0, config.getInt("cooldown-seconds", 5));

      ConfigManager.StorageType storageType;
      try {
         storageType = ConfigManager.StorageType.valueOf(config.getString("storage.type", "sqlite").toUpperCase(Locale.ROOT));
      } catch (IllegalArgumentException var15) {
         storageType = ConfigManager.StorageType.SQLITE;
      }

      this.storage = new ConfigManager.StorageSettings(
         storageType,
         config.getString("storage.sqlite-file", "stats.db"),
         config.getString("storage.yaml-file", "stats.yml"),
         Math.max(30, config.getInt("storage.save-interval-seconds", 300))
      );
      long diamondMinBet = Math.max(1L, config.getLong("diamond-roulette.min-bet", 10L));
      long diamondMaxBet = Math.max(diamondMinBet, config.getLong("diamond-roulette.max-bet", 100000L));
      this.diamond = new ConfigManager.DiamondSettings(
         config.getString("diamond-roulette.currency", "аметистов"),
         diamondMinBet,
         diamondMaxBet,
         this.readSectors(config),
         Math.max(5, config.getInt("diamond-roulette.animation-ticks", 40)),
         Math.max(1, config.getInt("diamond-roulette.tick-period", 2))
      );
      this.resource = new ConfigManager.ResourceSettings(
         Math.min(100, Math.max(1, config.getInt("resource-roulette.win-chance", 35))),
         this.readResourceMultipliers(config),
         this.readBlockedMaterials(config),
         this.readBlockedItems(config),
         Math.max(0, config.getInt("resource-roulette.cooldown_hours", 5)),
         Math.max(5, config.getInt("resource-roulette.animation-ticks", 20)),
         Math.max(1, config.getInt("resource-roulette.tick-period", 2)),
         Math.max(0, config.getInt("resource-roulette.cooldown-seconds", this.cooldownSeconds))
      );
      long treasureMinBet = Math.max(1L, config.getLong("treasure-hunt.min-bet", 10L));
      long treasureMaxBet = Math.max(treasureMinBet, config.getLong("treasure-hunt.max-bet", 100000L));
      long treasureStep = Math.max(1L, config.getLong("treasure-hunt.step", 10L));
      long treasureBigStep = Math.max(treasureStep, config.getLong("treasure-hunt.big-step", 100L));
      this.treasure = new ConfigManager.TreasureSettings(
         Math.min(8, Math.max(1, config.getInt("treasure-hunt.bombs", 6))),
         Math.min(0.5, Math.max(0.0, config.getDouble("treasure-hunt.house-edge", 0.2))),
         config.getString("treasure-hunt.currency", "аметистов"),
         treasureMinBet,
         treasureMaxBet,
         treasureStep,
         treasureBigStep
      );
   }

   private List<ConfigManager.Sector> readSectors(FileConfiguration config) {
      List<ConfigManager.Sector> sectors = new ArrayList<>();
      ConfigurationSection section = config.getConfigurationSection("diamond-roulette.sectors");
      if (section != null) {
         for (String key : section.getKeys(false)) {
            ConfigurationSection node = section.getConfigurationSection(key);
            if (node != null) {
               double multiplier = Math.max(0.0, node.getDouble("multiplier", 0.0));
               sectors.add(
                  new ConfigManager.Sector(
                     key,
                     material(node.getString("material"), Material.DIAMOND),
                     multiplier,
                     Math.max(1, node.getInt("weight", 1)),
                     MINI.deserialize(node.getString("display", "<white>x" + multiplier))
                  )
               );
            }
         }
      }

      if (sectors.isEmpty()) {
         sectors.add(new ConfigManager.Sector("zero", Material.COAL, 0.0, 35, MINI.deserialize("<dark_gray>Уголь x0")));
         sectors.add(new ConfigManager.Sector("one", Material.COPPER_INGOT, 1.0, 30, MINI.deserialize("<gold>Медь x1")));
         sectors.add(new ConfigManager.Sector("iron", Material.RAW_IRON, 1.25, 15, MINI.deserialize("<white>Железо x1.25")));
         sectors.add(new ConfigManager.Sector("gold", Material.RAW_GOLD, 1.5, 10, MINI.deserialize("<gold>Золото x1.5")));
         sectors.add(new ConfigManager.Sector("lapis", Material.LAPIS_LAZULI, 1.75, 6, MINI.deserialize("<blue>Лазурит x1.75")));
         sectors.add(new ConfigManager.Sector("diamond", Material.DIAMOND, 2.0, 4, MINI.deserialize("<aqua>Алмаз x2")));
      }

      return List.copyOf(sectors);
   }

   private List<ConfigManager.ResourceMultiplier> readResourceMultipliers(FileConfiguration config) {
      List<ConfigManager.ResourceMultiplier> multipliers = new ArrayList<>();
      ConfigurationSection section = config.getConfigurationSection("resource-roulette.multipliers");
      if (section != null) {
         for (String key : section.getKeys(false)) {
            ConfigurationSection node = section.getConfigurationSection(key);
            if (node != null) {
               double multiplier = Math.max(1.0, node.getDouble("multiplier", 2.0));
               multipliers.add(
                  new ConfigManager.ResourceMultiplier(
                     key, multiplier, Math.max(1, node.getInt("weight", 1)), MINI.deserialize(node.getString("display", "<white>x" + multiplier))
                  )
               );
            }
         }
      }

      if (multipliers.isEmpty()) {
         multipliers.add(new ConfigManager.ResourceMultiplier("double", 2.0, 100, MINI.deserialize("<green>x2")));
      }

      return List.copyOf(multipliers);
   }

   private List<Material> readBlockedMaterials(FileConfiguration config) {
      List<Material> blocked = new ArrayList<>();

      for (String raw : config.getStringList("resource-roulette.blocked-materials")) {
         Material material = Material.matchMaterial(raw.toUpperCase(Locale.ROOT));
         if (material != null) {
            blocked.add(material);
         }
      }

      return List.copyOf(blocked);
   }

   private List<String> readBlockedItems(FileConfiguration config) {
      List<String> blocked = new ArrayList<>();

      for (String raw : config.getStringList("resource-roulette.blocked-items")) {
         if (raw != null && !raw.isBlank()) {
            String trimmed = raw.trim();
            if (!blocked.contains(trimmed)) {
               blocked.add(trimmed);
            }
         }
      }

      return List.copyOf(blocked);
   }

   private static Material material(String raw, Material fallback) {
      if (raw != null && !raw.isBlank()) {
         Material material = Material.matchMaterial(raw.toUpperCase(Locale.ROOT));
         return material == null ? fallback : material;
      } else {
         return fallback;
      }
   }

   public ConfigManager.StorageSettings storage() {
      return this.storage;
   }

   public ConfigManager.DiamondSettings diamond() {
      return this.diamond;
   }

   public ConfigManager.TreasureSettings treasure() {
      return this.treasure;
   }

   public ConfigManager.ResourceSettings resource() {
      return this.resource;
   }

   public int cooldownSeconds() {
      return this.cooldownSeconds;
   }

   public static record DiamondSettings(
      String currency, long minBet, long maxBet, List<ConfigManager.Sector> sectors, int animationTicks, int tickPeriod
   ) {
      public long clamp(long amount) {
         return Math.min(this.maxBet, Math.max(this.minBet, amount));
      }

      public ConfigManager.Sector random(ThreadLocalRandom random) {
         int total = 0;

         for (ConfigManager.Sector sector : this.sectors) {
            total += sector.weight();
         }

         int roll = random.nextInt(Math.max(1, total));

         for (ConfigManager.Sector sector : this.sectors) {
            roll -= sector.weight();
            if (roll < 0) {
               return sector;
            }
         }

         return this.sectors.getLast();
      }

      public int indexOf(ConfigManager.Sector sector) {
         return this.sectors.indexOf(sector);
      }
   }

   public static record ResourceMultiplier(String key, double multiplier, int weight, Component display) {
   }

   public static record ResourceSettings(
      int winChance,
      List<ConfigManager.ResourceMultiplier> multipliers,
      List<Material> blocked,
      List<String> blockedNames,
      int cooldownHours,
      int animationTicks,
      int tickPeriod,
      int cooldownSeconds
   ) {
      public boolean allowed(Material material) {
         return this.forbiddenName(material, null) == null;
      }

      public boolean allowed(ItemStack stack) {
         return this.forbiddenName(stack) == null;
      }

      public String forbiddenName(ItemStack stack) {
         if (stack == null) {
            return null;
         }

         return this.forbiddenName(stack.getType(), customName(stack));
      }

      public String forbiddenName(Material material) {
         return this.forbiddenName(material, null);
      }

      private String forbiddenName(Material material, String customName) {
         if (material == null) {
            return null;
         } else if (material.isAir() || !material.isItem()) {
            return label(material, customName);
         } else if (this.blocked.contains(material) || alwaysBlocked(material)) {
            return label(material, customName);
         } else if (this.blockedNames.isEmpty()) {
            return null;
         } else {
            String name = material.name();
            String key = material.getKey().toString();
            String namespaced = "minecraft:" + name.toLowerCase(Locale.ROOT);
            String spaced = name.replace('_', ' ');

            for (String rule : this.blockedNames) {
               if (rule.equalsIgnoreCase(name) || rule.equalsIgnoreCase(key) || rule.equalsIgnoreCase(namespaced) || rule.equalsIgnoreCase(spaced)) {
                  return label(material, customName);
               }

               if (customName != null && !customName.isBlank() && rule.equalsIgnoreCase(customName)) {
                  return customName;
               }
            }

            return null;
         }
      }

      private static String label(Material material, String customName) {
         return customName == null || customName.isBlank() ? material.name() : customName;
      }

      private static boolean alwaysBlocked(Material material) {
         String name = material.name();
         return material == Material.SHULKER_BOX || name.endsWith("_SHULKER_BOX") || material == Material.BUNDLE || material == Material.MACE;
      }

      private static String customName(ItemStack stack) {
         if (!stack.hasItemMeta()) {
            return null;
         }

         ItemMeta meta = stack.getItemMeta();
         if (meta == null || !meta.hasDisplayName()) {
            return null;
         }

         Component display = meta.displayName();
         return display == null ? null : PLAIN.serialize(display).trim();
      }

      public ConfigManager.ResourceMultiplier randomMultiplier(ThreadLocalRandom random) {
         int total = 0;

         for (ConfigManager.ResourceMultiplier value : this.multipliers) {
            total += value.weight();
         }

         int roll = random.nextInt(Math.max(1, total));

         for (ConfigManager.ResourceMultiplier value : this.multipliers) {
            roll -= value.weight();
            if (roll < 0) {
               return value;
            }
         }

         return this.multipliers.getLast();
      }
   }

   public static record Sector(String key, Material material, double multiplier, int weight, Component display) {
   }

   public static record StorageSettings(ConfigManager.StorageType type, String sqliteFile, String yamlFile, int saveIntervalSeconds) {
   }

   public static enum StorageType {
      SQLITE,
      YAML;
   }

   public static record TreasureSettings(int bombs, double houseEdge, String currency, long minBet, long maxBet, long step, long bigStep) {
      public long clamp(long amount) {
         return Math.min(this.maxBet, Math.max(this.minBet, amount));
      }

      public double multiplierFor(int opened, int grid) {
         if (opened <= 0) {
            return 0.0;
         } else {
            double multiplier = 1.0;
            int safe = Math.max(1, grid - this.bombs);

            for (int index = 0; index < opened; index++) {
               multiplier *= (double)(grid - index) / (double)Math.max(1, safe - index);
            }

            return multiplier * (1.0 - this.houseEdge);
         }
      }
   }
}
