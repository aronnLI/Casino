package com.multitool.casino.economy;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.plugin.Plugin;

public final class PlayerPointsService {
   private final Object api;
   private final Method look;
   private final Method take;
   private final Method give;

   private PlayerPointsService(Object api, Method look, Method take, Method give) {
      this.api = api;
      this.look = look;
      this.take = take;
      this.give = give;
   }

   public static PlayerPointsService create() throws ReflectiveOperationException {
      Plugin plugin = Bukkit.getPluginManager().getPlugin("PlayerPoints");
      if (plugin == null) {
         return null;
      } else {
         ClassLoader loader = plugin.getClass().getClassLoader();
         Class<?> pluginClass = Class.forName("org.black_ixx.playerpoints.PlayerPoints", true, loader);
         Object api = pluginClass.getMethod("getAPI").invoke(plugin);
         if (api == null) {
            return null;
         } else {
            Class<?> apiClass = Class.forName("org.black_ixx.playerpoints.PlayerPointsAPI", true, loader);
            return new PlayerPointsService(
               api,
               apiClass.getMethod("look", UUID.class),
               apiClass.getMethod("take", UUID.class, int.class),
               apiClass.getMethod("give", UUID.class, int.class)
            );
         }
      }
   }

   public long balance(UUID uuid) {
      try {
         return this.look.invoke(this.api, uuid) instanceof Number number ? Math.max(0L, number.longValue()) : 0L;
      } catch (InvocationTargetException | IllegalAccessException var4) {
         return 0L;
      }
   }

   public boolean take(UUID uuid, long amount) {
      if (amount <= 0L) {
         return true;
      } else if (amount > 2147483647L) {
         return false;
      } else {
         try {
            return Boolean.TRUE.equals(this.take.invoke(this.api, uuid, (int)amount));
         } catch (InvocationTargetException | IllegalAccessException var5) {
            return false;
         }
      }
   }

   public boolean give(UUID uuid, long amount) {
      if (amount <= 0L) {
         return true;
      } else if (amount > 2147483647L) {
         return false;
      } else {
         try {
            return Boolean.TRUE.equals(this.give.invoke(this.api, uuid, (int)amount));
         } catch (InvocationTargetException | IllegalAccessException var5) {
            return false;
         }
      }
   }
}
