package com.multitool.casino.plugin;

import com.multitool.casino.commands.CasinoAdminCommand;
import com.multitool.casino.commands.CasinoCommand;
import com.multitool.casino.config.ConfigManager;
import com.multitool.casino.config.Messages;
import com.multitool.casino.economy.PlayerPointsService;
import com.multitool.casino.games.DiamondRouletteGame;
import com.multitool.casino.games.ResourceRouletteCooldown;
import com.multitool.casino.games.ResourceRouletteGame;
import com.multitool.casino.games.TreasureHuntGame;
import com.multitool.casino.listeners.GuiListener;
import com.multitool.casino.listeners.PlayerListener;
import com.multitool.casino.storage.SqliteStatsRepository;
import com.multitool.casino.storage.StatsRepository;
import com.multitool.casino.storage.StatsService;
import com.multitool.casino.storage.YamlStatsRepository;
import com.multitool.casino.utils.CooldownManager;
import java.nio.file.Path;
import org.bukkit.command.PluginCommand;
import org.bukkit.plugin.java.JavaPlugin;

public final class CasinoPlugin extends JavaPlugin {
   private ConfigManager configManager;
   private Messages messages;
   private StatsRepository repository;
   private StatsService statsService;
   private CooldownManager resourceCooldowns;
   private PlayerPointsService points;
   private DiamondRouletteGame diamondGame;
   private ResourceRouletteGame resourceGame;
   private ResourceRouletteCooldown resourceCooldown;
   private TreasureHuntGame treasureGame;

   public void onEnable() {
      this.saveDefaultConfig();
      this.configManager = new ConfigManager(this);
      this.messages = new Messages(this);
      this.messages.reload();
      this.resourceCooldowns = new CooldownManager(this.configManager.resource().cooldownSeconds());

      try {
         this.repository = this.createRepository();
      } catch (RuntimeException var4) {
         this.getLogger().severe("Не удалось инициализировать хранилище статистики: " + var4.getMessage());
         this.getServer().getPluginManager().disablePlugin(this);
         return;
      }

      this.statsService = new StatsService(this, this.repository);
      this.statsService.start();

      try {
         this.points = PlayerPointsService.create();
      } catch (Throwable var3) {
         this.getLogger().warning("Не удалось подключить PlayerPoints API: " + var3.getMessage());
         this.points = null;
      }

      if (this.points == null) {
         this.getLogger().warning("PlayerPoints не найден: алмазная рулетка отключена, ресурсная работает.");
      }

      this.diamondGame = new DiamondRouletteGame(this, this.configManager, this.messages, this.statsService, this.points);
      this.resourceCooldown = new ResourceRouletteCooldown(this);
      this.resourceGame = new ResourceRouletteGame(this, this.configManager, this.messages, this.statsService, this.resourceCooldowns);
      this.treasureGame = new TreasureHuntGame(this, this.configManager, this.messages, this.statsService, this.points);
      this.getServer().getPluginManager().registerEvents(new GuiListener(this), this);
      this.getServer().getPluginManager().registerEvents(new PlayerListener(this), this);
      PluginCommand casinoCommand = this.getCommand("casino");
      if (casinoCommand == null) {
         this.getLogger().severe("Команда /casino не зарегистрирована в plugin.yml.");
      } else {
         CasinoCommand executor = new CasinoCommand(this);
         casinoCommand.setExecutor(executor);
         casinoCommand.setTabCompleter(executor);
      }

      PluginCommand adminCommand = this.getCommand("casinoadmin");
      if (adminCommand == null) {
         this.getLogger().severe("Команда /casinoadmin не зарегистрирована в plugin.yml.");
      } else {
         CasinoAdminCommand adminExecutor = new CasinoAdminCommand(this);
         adminCommand.setExecutor(adminExecutor);
         adminCommand.setTabCompleter(adminExecutor);
      }

      this.getLogger().info("Casino включён. Игры: алмазная рулетка, ресурсная рулетка. Хранилище: " + this.configManager.storage().type() + ".");
   }

   public void onDisable() {
      this.getServer().getScheduler().cancelTasks(this);
      if (this.diamondGame != null) {
         this.diamondGame.shutdown();
      }

      if (this.resourceGame != null) {
         this.resourceGame.shutdown();
      }

      if (this.treasureGame != null) {
         this.treasureGame.shutdown();
      }

      if (this.statsService != null) {
         this.statsService.close();
      }
   }

   public void reloadPlugin() {
      this.configManager.reload();
      this.messages.reload();
      this.resourceCooldowns.seconds(this.configManager.resource().cooldownSeconds());
   }

   private StatsRepository createRepository() {
      ConfigManager.StorageSettings storage = this.configManager.storage();
      Path folder = this.getDataFolder().toPath();

      return (StatsRepository)(switch (storage.type()) {
         case SQLITE -> {
            SqliteStatsRepository var7;
            try {
               var7 = new SqliteStatsRepository(folder.resolve(storage.sqliteFile()), this.getLogger());
            } catch (RuntimeException var5) {
               this.getLogger()
                  .severe(
                     "SQLite недоступна ("
                        + var5.getMessage()
                        + "), используется YAML. Драйвер подгружается Paper с Maven Central при первом запуске — проверьте доступ сервера к сети."
                  );
               YamlStatsRepository var6 = new YamlStatsRepository(folder.resolve(storage.yamlFile()), this.getLogger());
               yield var6;
            }

            yield var7;
         }
         case YAML -> {
            YamlStatsRepository var3 = new YamlStatsRepository(folder.resolve(storage.yamlFile()), this.getLogger());
            yield var3;
         }
      });
   }

   public ConfigManager configManager() {
      return this.configManager;
   }

   public Messages messages() {
      return this.messages;
   }

   public StatsService statsService() {
      return this.statsService;
   }

   public PlayerPointsService points() {
      return this.points;
   }

   public DiamondRouletteGame diamondGame() {
      return this.diamondGame;
   }

   public TreasureHuntGame treasureGame() {
      return this.treasureGame;
   }

   public ResourceRouletteGame resourceGame() {
      return this.resourceGame;
   }

   public ResourceRouletteCooldown resourceCooldown() {
      return this.resourceCooldown;
   }
}
