package com.multitool.casino.listeners.gui;

import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;

public final class GuiHolder implements InventoryHolder {
   private final GuiHolder.Type type;
   private Inventory inventory;
   private boolean locked;
   private int inputSlot = -1;
   private int[] inputSlots = new int[0];
   private long amount;

   public GuiHolder(GuiHolder.Type type) {
      this.type = type;
   }

   public GuiHolder.Type type() {
      return this.type;
   }

   public Inventory getInventory() {
      return this.inventory;
   }

   public void inventory(Inventory inventory) {
      this.inventory = inventory;
   }

   public boolean locked() {
      return this.locked;
   }

   public void locked(boolean locked) {
      this.locked = locked;
   }

   public long amount() {
      return this.amount;
   }

   public void amount(long amount) {
      this.amount = amount;
   }

   public int inputSlot() {
      return this.inputSlot;
   }

   public void inputSlot(int inputSlot) {
      this.inputSlot = inputSlot;
   }

   public int[] inputSlots() {
      return this.inputSlots;
   }

   public void inputSlots(int... inputSlots) {
      this.inputSlots = inputSlots == null ? new int[0] : inputSlots;
   }

   public boolean isInput(int slot) {
      if (slot == this.inputSlot) {
         return true;
      } else {
         for (int value : this.inputSlots) {
            if (value == slot) {
               return true;
            }
         }

         return false;
      }
   }

   public static enum Type {
      MAIN,
      DIAMOND,
      RESOURCE,
      TREASURE_MENU,
      TREASURE_FIELD;
   }
}
