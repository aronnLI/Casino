package com.multitool.casino.storage;

import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;

public final class SqliteStatsRepository implements StatsRepository {
   private static final String CREATE_TABLE = "CREATE TABLE IF NOT EXISTS casino_stats (\n    uuid TEXT PRIMARY KEY,\n    name TEXT NOT NULL,\n    games INTEGER NOT NULL DEFAULT 0,\n    wins INTEGER NOT NULL DEFAULT 0,\n    losses INTEGER NOT NULL DEFAULT 0,\n    wagered INTEGER NOT NULL DEFAULT 0,\n    won INTEGER NOT NULL DEFAULT 0,\n    biggest_win INTEGER NOT NULL DEFAULT 0,\n    last_played INTEGER NOT NULL DEFAULT 0\n)";
   private static final String UPSERT = "INSERT INTO casino_stats (uuid, name, games, wins, losses, wagered, won, biggest_win, last_played)\nVALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)\nON CONFLICT(uuid) DO UPDATE SET\n    name = excluded.name,\n    games = excluded.games,\n    wins = excluded.wins,\n    losses = excluded.losses,\n    wagered = excluded.wagered,\n    won = excluded.won,\n    biggest_win = excluded.biggest_win,\n    last_played = excluded.last_played\n";
   private static final String SELECT_ONE = "SELECT name, games, wins, losses, wagered, won, biggest_win, last_played\nFROM casino_stats WHERE uuid = ?\n";
   private static final String SELECT_TOP = "SELECT uuid, name, games, wins, losses, wagered, won, biggest_win, last_played\nFROM casino_stats ORDER BY won DESC LIMIT ?\n";
   private static final String CREATE_RESOURCE_TABLE = "CREATE TABLE IF NOT EXISTS casino_resource_cooldown (\n    player_name TEXT NOT NULL,\n    ip_address TEXT NOT NULL,\n    last_play_time INTEGER NOT NULL,\n    PRIMARY KEY (player_name, ip_address)\n)";
   private static final String CREATE_RESOURCE_INDEX = "CREATE INDEX IF NOT EXISTS casino_resource_cooldown_ip ON casino_resource_cooldown (ip_address)";
   private static final String SELECT_RESOURCE_LAST = "SELECT COALESCE(MAX(last_play_time), 0)\nFROM casino_resource_cooldown WHERE LOWER(player_name) = LOWER(?) OR ip_address = ?\n";
   private static final String UPSERT_RESOURCE_PLAY = "INSERT INTO casino_resource_cooldown (player_name, ip_address, last_play_time)\nVALUES (?, ?, ?)\nON CONFLICT(player_name, ip_address) DO UPDATE SET\n    last_play_time = excluded.last_play_time\n";
   private final Logger logger;
   private final ExecutorService executor;
   private final Connection connection;

   public SqliteStatsRepository(Path file, Logger logger) {
      this.logger = logger;
      this.executor = Executors.newSingleThreadExecutor(Thread.ofVirtual().name("casino-sqlite-", 0L).factory());

      Connection opened;
      try {
         Path parent = file.toAbsolutePath().getParent();
         if (parent != null) {
            Files.createDirectories(parent);
         }

         opened = DriverManager.getConnection("jdbc:sqlite:" + file.toAbsolutePath());

          try (Statement statement = opened.createStatement()) {
             statement.executeUpdate(
                "CREATE TABLE IF NOT EXISTS casino_stats (\n    uuid TEXT PRIMARY KEY,\n    name TEXT NOT NULL,\n    games INTEGER NOT NULL DEFAULT 0,\n    wins INTEGER NOT NULL DEFAULT 0,\n    losses INTEGER NOT NULL DEFAULT 0,\n    wagered INTEGER NOT NULL DEFAULT 0,\n    won INTEGER NOT NULL DEFAULT 0,\n    biggest_win INTEGER NOT NULL DEFAULT 0,\n    last_played INTEGER NOT NULL DEFAULT 0\n)"
             );
             statement.executeUpdate(CREATE_RESOURCE_TABLE);
             statement.executeUpdate(CREATE_RESOURCE_INDEX);
          }
      } catch (Exception var10) {
         throw new IllegalStateException("Не удалось открыть базу SQLite " + file, var10);
      }

      this.connection = opened;
   }

   @Override
   public CompletableFuture<PlayerStats> update(UUID uuid, String name, long stake, long payout) {
      return this.submit("update", () -> {
         PlayerStats updated = this.read(uuid, name).withGame(name, stake, payout);
         this.write(updated);
         return updated;
      }, PlayerStats.empty(uuid, name));
   }

   @Override
   public CompletableFuture<PlayerStats> find(UUID uuid, String name) {
      return this.submit("find", () -> this.read(uuid, name), PlayerStats.empty(uuid, name));
   }

   @Override
   public CompletableFuture<List<PlayerStats>> top(int limit) {
      List<PlayerStats> fallback = List.of();
      return this.submit(
         "top",
         () -> {
            List<PlayerStats> result = new ArrayList<>();

            try (PreparedStatement statement = this.connection
                  .prepareStatement(
                     "SELECT uuid, name, games, wins, losses, wagered, won, biggest_win, last_played\nFROM casino_stats ORDER BY won DESC LIMIT ?\n"
                  )) {
               statement.setInt(1, Math.max(1, limit));

               try (ResultSet resultSet = statement.executeQuery()) {
                  while (resultSet.next()) {
                     result.add(this.read(resultSet));
                  }
               }
            }

            return List.copyOf(result);
         },
         fallback
      );
   }

   @Override
   public CompletableFuture<Long> lastResourcePlay(String playerName, String ipAddress) {
      String name = playerName == null ? "" : playerName;
      String ip = ipAddress == null ? "" : ipAddress;
      return this.submit("lastResourcePlay", () -> {
         try (PreparedStatement statement = this.connection.prepareStatement(SELECT_RESOURCE_LAST)) {
            statement.setString(1, name);
            statement.setString(2, ip);

            try (ResultSet resultSet = statement.executeQuery()) {
               return resultSet.next() ? resultSet.getLong(1) : 0L;
            }
         }
      }, 0L);
   }

   @Override
   public CompletableFuture<Void> markResourcePlay(String playerName, String ipAddress, long time) {
      String name = playerName == null ? "" : playerName;
      String ip = ipAddress == null ? "" : ipAddress;
      return this.submit("markResourcePlay", () -> {
         try (PreparedStatement statement = this.connection.prepareStatement(UPSERT_RESOURCE_PLAY)) {
            statement.setString(1, name);
            statement.setString(2, ip);
            statement.setLong(3, time);
            statement.executeUpdate();
         }

         return null;
      }, null);
   }

   @Override
   public void flush() {
   }

   @Override
   public void close() {
      this.executor.shutdown();

      try {
         if (!this.executor.awaitTermination(10L, TimeUnit.SECONDS)) {
            this.executor.shutdownNow();
         }
      } catch (InterruptedException var3) {
         Thread.currentThread().interrupt();
      }

      try {
         this.connection.close();
      } catch (SQLException var2) {
         this.logger.log(Level.WARNING, "Не удалось закрыть соединение SQLite", (Throwable)var2);
      }
   }

   private <T> CompletableFuture<T> submit(String action, SqliteStatsRepository.SqlSupplier<T> supplier, T fallback) {
      CompletableFuture<T> future = new CompletableFuture<>();
      this.executor.execute(() -> {
         try {
            future.complete(supplier.get());
         } catch (Throwable var6) {
            this.logger.log(Level.SEVERE, "Ошибка SQLite при операции " + action, var6);
            future.complete(fallback);
         }
      });
      return future;
   }

   private PlayerStats read(UUID uuid, String name) throws SQLException {
      PlayerStats var11;
      try (PreparedStatement statement = this.connection
            .prepareStatement("SELECT name, games, wins, losses, wagered, won, biggest_win, last_played\nFROM casino_stats WHERE uuid = ?\n")) {
         statement.setString(1, uuid.toString());

         try (ResultSet resultSet = statement.executeQuery()) {
            if (!resultSet.next()) {
               return PlayerStats.empty(uuid, name);
            }

            var11 = new PlayerStats(
               uuid,
               resultSet.getString("name"),
               resultSet.getLong("games"),
               resultSet.getLong("wins"),
               resultSet.getLong("losses"),
               resultSet.getLong("wagered"),
               resultSet.getLong("won"),
               resultSet.getLong("biggest_win"),
               resultSet.getLong("last_played")
            );
         }
      }

      return var11;
   }

   private PlayerStats read(ResultSet resultSet) throws SQLException {
      return new PlayerStats(
         UUID.fromString(resultSet.getString("uuid")),
         resultSet.getString("name"),
         resultSet.getLong("games"),
         resultSet.getLong("wins"),
         resultSet.getLong("losses"),
         resultSet.getLong("wagered"),
         resultSet.getLong("won"),
         resultSet.getLong("biggest_win"),
         resultSet.getLong("last_played")
      );
   }

   private void write(PlayerStats stats) throws SQLException {
      try (PreparedStatement statement = this.connection
            .prepareStatement(
               "INSERT INTO casino_stats (uuid, name, games, wins, losses, wagered, won, biggest_win, last_played)\nVALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)\nON CONFLICT(uuid) DO UPDATE SET\n    name = excluded.name,\n    games = excluded.games,\n    wins = excluded.wins,\n    losses = excluded.losses,\n    wagered = excluded.wagered,\n    won = excluded.won,\n    biggest_win = excluded.biggest_win,\n    last_played = excluded.last_played\n"
            )) {
         statement.setString(1, stats.uuid().toString());
         statement.setString(2, stats.name());
         statement.setLong(3, stats.games());
         statement.setLong(4, stats.wins());
         statement.setLong(5, stats.losses());
         statement.setLong(6, stats.wagered());
         statement.setLong(7, stats.won());
         statement.setLong(8, stats.biggestWin());
         statement.setLong(9, stats.lastPlayed());
         statement.executeUpdate();
      }
   }

   @FunctionalInterface
   private interface SqlSupplier<T> {
      T get() throws Exception;
   }
}
